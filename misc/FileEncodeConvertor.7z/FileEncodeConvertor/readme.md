FileEncConv
---

+ Reference

    - [文件編碼批量轉換為utf-8](https://www.twblogs.net/a/5f04ee191a766f6a61d0dc3f)
    - [CodeTransmit-github](https://github.com/clorymmk/CodeTransmit)
