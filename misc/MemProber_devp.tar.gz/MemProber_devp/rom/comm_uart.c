/**
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 */
/** @file comm_uart.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/12
 * @license
 * @description
 */


#include <stdbool.h>
#include "comm_desc.h"
#include "phoenix_periph.h"
#include "util.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
//#define CFG_USE_PRIVATE_BUF

#define UART_BUFFER_LENGTH      64 // it MUST power of 2


typedef enum uart_console_id
{
    UART_CONSOLE_ID_0   = 0,
    UART_CONSOLE_ID_1,
    UART_CONSOLE_ID_MAX
} uart_console_id_t;
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct uart_dev
{
    uint16_t            is_used;
    uint16_t            has_rx_event;
    UART_TypeDef        *pHUart;

    volatile uint16_t   rd_idx;
    volatile uint16_t   wr_idx;

#if defined(CFG_USE_PRIVATE_BUF)
    uint8_t             pRx_buf[UART_BUFFER_LENGTH];
#else
	uint8_t 			*pRx_buf;
	uint32_t 			rx_buf_len;
#endif
} uart_dev_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
static UART_TypeDef     *g_hUart[] =
{
#if defined(CORE_M4)
    UART0, UART1,
#else
    #error "You MUST define 'CORE_M4'"
#endif
};

static IRQn_Type        g_uart_irq[] =
{
#if defined(CORE_M4)
    UART0_IRQn, UART1_IRQn,
#else
    #error "You MUST define 'CORE_M4'"
#endif
};

static uart_dev_t       g_uart_dev[UART_CONSOLE_ID_MAX] = {{0}};
//=============================================================================
//                  Private Function Definition
//=============================================================================
static void
_uart_isr(uart_dev_t  *pDev)
{
	uint8_t     int_status = pDev->pHUart->IIR;
	uint32_t    rd_idx = pDev->rd_idx;
	uint32_t    wr_idx = pDev->wr_idx;
    uint32_t    pos = 0;

#if defined(CFG_USE_PRIVATE_BUF)
    pos = (wr_idx + 1) & (UART_BUFFER_LENGTH - 1);
#else
    pos = (wr_idx + 1) % pDev->rx_buf_len;
#endif

    if( pos == rd_idx )
    {
        // buffer full checking
		while(1)
			__asm("nop");
    }

	pDev->pRx_buf[wr_idx] = UART_ReceiveData(pDev->pHUart);
	pDev->wr_idx          = pos;
	pDev->has_rx_event    = (uint16_t)true;
	return;
}

void UART0_IRQHandler(void)
{
    uart_dev_t  *pDev = &g_uart_dev[UART_CONSOLE_ID_0];
    _uart_isr(pDev);
    return;
}

void UART1_IRQHandler(void)
{
    uart_dev_t  *pDev = &g_uart_dev[UART_CONSOLE_ID_1];
    _uart_isr(pDev);
    return;
}


static comm_handle_t
_uart_init(comm_cfg_t *pCfg)
{
    uart_dev_t          *pUart_dev = 0;

    _assert(pCfg);
    _assert((pCfg->uart.port == 0) || (pCfg->uart.port == 1));

    do {
        UART_InitTypeDef    uart_setting = {0};

        if( g_uart_dev[pCfg->uart.port].is_used )
            break;

        pUart_dev = &g_uart_dev[pCfg->uart.port];
        pUart_dev->is_used    = true;
        pUart_dev->pHUart     = g_hUart[pCfg->uart.port];
        pUart_dev->wr_idx     = 0;
        pUart_dev->rd_idx     = 0;

        #if !defined(CFG_USE_PRIVATE_BUF)
        pUart_dev->pRx_buf    = pCfg->pBuf;
        pUart_dev->rx_buf_len = pCfg->buf_len;
        #endif

        /* USARTx configured as follow:
         *  - BaudRate = 115200 baud
         *  - Word Length = 8 Bits
         *  - Stop Bit = 1 Stop Bit
         *  - Parity = No Parity
         *  - Hardware flow control disabled (RTS and CTS signals)
         *  - Receive and transmit enabled
         */
        uart_setting.UART_BaudRate            = pCfg->uart.baud_rate;
        uart_setting.UART_WordLength          = 0; // USART_WordLength_8b;
        uart_setting.UART_StopBits            = 0; // USART_StopBits_1;
        uart_setting.UART_Parity              = 0; // USART_Parity_No;
        uart_setting.UART_HardwareFlowControl = 0; // USART_HardwareFlowControl_None;
        uart_setting.UART_Mode                = 0; // USART_Mode_Rx | USART_Mode_Tx;

        UART_Init(pUart_dev->pHUart, &uart_setting);
        UART_ITConfig(pUart_dev->pHUart, UART_IT_RXNE, ENABLE);
        NVIC_EnableIRQ(g_uart_irq[pCfg->uart.port]);
        NVIC_ClearPendingIRQ(g_uart_irq[pCfg->uart.port]);
    } while(0);

	return (comm_handle_t)pUart_dev;
}

static int
_uart_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    int     rval = 0;

    do {
        uart_dev_t      *pUart_dev = (uart_dev_t*)pHandle;
        int             i = 0;

        if( pHandle == 0 || pData == 0 || data_len == 0 )
        {
            rval = -1;
            break;
        }

        while( i < data_len )
        {
            while(((UART_ReadLineStatus(pUart_dev->pHUart)) & UART_LSR_THRE) == 0) {}

            USART_SendData(pUart_dev->pHUart, *((volatile uint8_t*)(pData + i)));
            i++;
        }

    } while(0);
    return rval;
}

static int
_uart_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    int     rval = 0;

    do {
        uart_dev_t      *pUart_dev = (uart_dev_t*)pHandle;
        int             len = 0;
        int             rd_idx = pUart_dev->rd_idx;
        int             wr_idx = pUart_dev->wr_idx;

        if( pHandle == 0 )
        {
            rval = -1;
            break;
        }

        while( 1 )
        {
            if( rd_idx == wr_idx )      break;
            if( *pData_len == len )     break;

        #if defined(CFG_USE_PRIVATE_BUF)
            *pData++ = pUart_dev->pRx_buf[rd_idx];

            rd_idx = (rd_idx + 1) & (UART_BUFFER_LENGTH - 1);
        #else
            rd_idx = (rd_idx + 1) % pUart_dev->rx_buf_len;
        #endif // defined

            len++ ;
        }

        pUart_dev->rd_idx = rd_idx;
        *pData_len = len;

    } while(0);
    return rval;
}

static int
_uart_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
    uart_dev_t      *pUart_dev = (uart_dev_t*)pHandle;

    if( pHandle == 0 )  return -1;

    if( state == COMM_STATE_GET_RX_EVENT )
    {
        uint32_t    rd_idx = pUart_dev->rd_idx;
        uint32_t    wr_idx = pUart_dev->wr_idx;
        // if empty, no rx_event
        rval = !(rd_idx == wr_idx);
    }

    return rval;
}

static int
_uart_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
        uart_dev_t      *pUart_dev = (uart_dev_t*)pHandle;

        if( pHandle == 0 )
        {
            rval = -1;
            break;
        }
#if !defined(CFG_USE_PRIVATE_BUF)
        pUart_dev->rd_idx = 0;
        pUart_dev->wr_idx = 0;

        if( pBuf && buf_len )
        {
            pUart_dev->pRx_buf    = pBuf;
            pUart_dev->rx_buf_len = buf_len;
        }
#endif
    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_desc_t     g_comm_console_0 =
{
    .init       = _uart_init,
    .send_bytes = _uart_send_bytes,
    .recv_bytes = _uart_recv_bytes,
    .get_state  = _uart_get_state,
    .reset_buf  = _uart_reset_buf,
};

comm_desc_t     g_comm_console_1 =
{
    .init       = _uart_init,
    .send_bytes = _uart_send_bytes,
    .recv_bytes = _uart_recv_bytes,
    .get_state  = _uart_get_state,
    .reset_buf  = _uart_reset_buf,
};
