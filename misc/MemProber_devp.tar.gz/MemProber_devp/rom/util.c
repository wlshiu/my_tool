/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file util.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/12
 * @license
 * @description
 */


#include <stdint.h>
#include "util.h"
//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================

#if !(CONFIG_USE_STD_LIBC)
size_t
vt_strlen(const char* str)
{
	const char  *sc = str;
	while( *sc != '\0' )     sc++;
	return sc - str;
}

char*
vt_strcpy(char *dest, const char *src)
{
    char    *ptr = dest;

    if( dest == NULL || src == NULL)
        return NULL;

    while( *src && (*dest++ = *src++) );

    *dest = '\0';
    return ptr;
}

void*
vt_memcpy(unsigned char* to, unsigned char* from, int count)
{
    int     n = (count+7) >> 3;
    switch( count & 0x7 )
    {
        case 0: do{ *to++ = *from++;
        case 7:     *to++ = *from++;
        case 6:     *to++ = *from++;
        case 5:     *to++ = *from++;
        case 4:     *to++ = *from++;
        case 3:     *to++ = *from++;
        case 2:     *to++ = *from++;
        case 1:     *to++ = *from++;
                }while(--n > 0);
    }
    return (void*)to;
}
#endif

void
assert_failed(
    const char  *func_name,
    uint32_t    line,
    char        *expr)
{
    while (1) {}
}



