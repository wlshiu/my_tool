/*
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 *
 */
/** @file isp.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/11
 * @license
 * @description
 */


#include "isp.h"

#include "flash_type.h"
#include "util.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#define CFG_ENABLE_DEBUG_MODE   1

typedef enum cmd_rst
{
    CMD_RST_DATA_READY  = 1,
    CMD_RST_WAIT_DATA   = 2,
    CMD_RST_FINISH      = 3,

    CMD_RST_OUT_BUF_LEN     = ISP_ACK_OUT_BUF_LEN,
    CMD_RST_MISCHECKSUM     = ISP_ACK_MISCHECKSUM,
    CMD_RST_TIMEOUT         = ISP_ACK_TIMEOUT,
    CMD_RST_NOT_SUPPORT     = ISP_ACK_NOT_SUPPORT,
    CMD_RST_FAIL            = ISP_ACK_UNKNOWN,
} cmd_rst_t;
//=============================================================================
//                  Macro Definition
//=============================================================================
#define CONVERT_LENGTH(len)         ((len) << 2)
//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct isp_cmd_attr
{
    ISP_CMD_t     cmd;

    cmd_rst_t   (*cmd_handler)(isp_handle_t *pHIsp, struct isp_cmd_attr *pAttr);
} isp_cmd_attr_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
#if defined(CFG_ENABLE_DEBUG_MODE)
#include <string.h>
uint32_t     g_debug_mem_poll[2048 >> 2] = {0};

#if 0
    #define _delay_sec(a)       do{for(int ggg = 0; ggg < a * 10000000; ggg++) __asm volatile ("nop"); }while(0)
#else
    #include <windows.h>
    #define _delay_sec(a)       do{int s = time(NULL); while( (time(NULL) - s) < a ) Sleep(100);}while(0)
#endif

#endif // defined(CFG_ENABLE_DEBUG_MODE)

static uint32_t     g_ack_cmd_value = ISP_CMD_ACK;
static uint32_t     g_buf[128 >> 2] = {0};
//=============================================================================
//                  Private Function Definition
//=============================================================================
#if 0
static cmd_rst_t
_cmd_xxx(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t      *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = ;

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        // message header
        {
            comm_hdr_t      hdr = {0};
            hdr.cmd     = (g_ack_cmd_value & 0xFF);
            hdr.status  = ISP_ACK_OK;
            hdr.length  =  ;
            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&hdr, sizeof(hdr));
        }

        //-------------------------
        // data

        //-------------------------
        // checksum


        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}
#endif // 0

static cmd_rst_t
_cmd_default(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_NOT_SUPPORT;
    return rval;
}

static cmd_rst_t
_verify_param(isp_handle_t *pHIsp, comm_hdr_t *pHdr_recv, int expected_len)
{
    cmd_rst_t   rval = CMD_RST_DATA_READY;
    do {
        pHIsp->timeout--;

        if( pHIsp->timeout < 0 )
        {
            rval = CMD_RST_TIMEOUT;
            break;
        }

        if( expected_len > pHIsp->valid_len )
        {
            rval = CMD_RST_WAIT_DATA;
            break;
        }

        if( CONVERT_LENGTH(pHdr_recv->length) > pHIsp->buffer_len )
        {
            rval = CMD_RST_OUT_BUF_LEN;
            break;
        }
    }while(0);
    return rval;
}

static cmd_rst_t
_verify_data(isp_handle_t *pHIsp, comm_hdr_t *pHdr_recv, int raw_len)
{
    cmd_rst_t   rval = CMD_RST_DATA_READY;
    do {
        uint8_t         *pCur = 0;
        uint8_t         *pChecksum = 0;
        uint32_t        calc_sum = 0;

        pCur = (uint8_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));
        pChecksum = (uint8_t*)((uint32_t)pCur + raw_len);

        // check sum
        for(int i = 0; i < raw_len; ++i)
        {
            calc_sum += *pCur++;
        }

        if( *pChecksum != (uint8_t)(calc_sum & 0xFF) )
        {
            rval = CMD_RST_MISCHECKSUM;
            break;
        }

    } while(0);
    return rval;
}

static uint8_t
_calc_sum(uint8_t *pAddr, int len)
{
    uint32_t    sum = 0;

    for(int i = 0; i < len; i++)
        sum += pAddr[i];

    return (sum & 0xFF);
}

#if 0
static cmd_rst_t
_cmd_ping(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    uint32_t    ack = FOUR_CC('p', 'h', 'n', 'x');

    comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                        (uint8_t*)&ack, sizeof(ack));

    rval = CMD_RST_FINISH;
    return rval;
}
#endif

static cmd_rst_t
_cmd_ping(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;

    do {
        uint32_t        ack[2] = {0};
        comm_hdr_t      hdr = {0};
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_OK;
        hdr.length  = sizeof(ack) >> 2;

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        ack[0] = FOUR_CC('V', 'A', 'N', 'G');
        ack[1] = FOUR_CC('p', 'h', 'n', 'x');
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&ack, sizeof(ack));

        //-------------------------
        // check sum
        {
            uint8_t     sum = 0;

            sum = _calc_sum((uint8_t*)&ack, sizeof(ack));

            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&sum, sizeof(sum));
        }

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_read_4bytes(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t      *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        uint32_t        addr = 0;
        uint32_t        read_len = 0;

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = CONVERT_LENGTH(pHdr_recv->length);

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        read_len = *((uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t) + sizeof(int)));
        //-------------------------
        // prepare data for sending
        {
            comm_hdr_t      hdr = {0};
            hdr.cmd     = (g_ack_cmd_value & 0xFF);
            hdr.status  = ISP_ACK_OK;
            hdr.length  = read_len;
            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&hdr, sizeof(hdr));
        }

        //-------------------------
        // data
        addr = *((uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t)));

    #if defined(CFG_ENABLE_DEBUG_MODE)
        if( CONVERT_LENGTH(read_len) == CONFIG_FLASH_PAGE_LENGTH )
        {
            static uint32_t     *pCur_addr = (uint32_t*)g_debug_mem_poll;

            addr = (uint32_t)pCur_addr;
            pCur_addr += read_len;
            if( pCur_addr >= (uint32_t*)&g_debug_mem_poll[(sizeof(g_debug_mem_poll) >> 2)] )
                pCur_addr = (uint32_t*)g_debug_mem_poll;
        }
        else
            addr = (uint32_t)&g_debug_mem_poll[0];
    #endif // defined(CFG_ENABLE_DEBUG_MODE)

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)addr, CONVERT_LENGTH(read_len));

        //-------------------------
        // check sum
        {
            uint8_t     sum = 0;

            sum = _calc_sum((uint8_t*)addr, CONVERT_LENGTH(read_len));

            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&sum, sizeof(sum));
        }

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_write_4bytes(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t      *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = 8;

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        // write data to memory
        {
            uint32_t    addr = 0, value = 0;
            uint32_t    *pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));

            addr  = *pRaw_cur;
            value = *(pRaw_cur + 1);

    #if defined(CFG_ENABLE_DEBUG_MODE)
            addr = (uint32_t)&g_debug_mem_poll[0];
    #endif // defined(CFG_ENABLE_DEBUG_MODE)

            *((volatile uint32_t*)addr) = value;
        }

        //-------------------------
        {   // message header
            comm_hdr_t      hdr = {0};
            hdr.cmd     = (g_ack_cmd_value & 0xFF);
            hdr.status  = ISP_ACK_OK;
            hdr.length  = 0;
            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&hdr, sizeof(hdr));
        }

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_write_data(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t      *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        comm_hdr_t      hdr = {0};

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = 4 + CONVERT_LENGTH(pHdr_recv->length);

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        // return ACK
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_SYSTEM_BUSY;
        hdr.length  = 0;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        //-------------------------
        // write data to memory
        {
            uint32_t    *pAddr = 0, len = 0;
            uint32_t    *pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));

            pAddr = (uint32_t*)(*pRaw_cur);
            len   = pHdr_recv->length;

            pRaw_cur++;

    #if defined(CFG_ENABLE_DEBUG_MODE)
            static uint32_t     *pCur_addr = (uint32_t*)g_debug_mem_poll;

            pAddr = (uint32_t*)pCur_addr;

            while( len-- )
            {
                *((volatile uint32_t*)pAddr++) = *pRaw_cur++;
            }

            pCur_addr += pHdr_recv->length;
            if( pCur_addr >= (uint32_t*)&g_debug_mem_poll[(sizeof(g_debug_mem_poll) >> 2)] )
                pCur_addr = (uint32_t*)g_debug_mem_poll;
    #else
            while( len-- )
            {
                *((volatile uint32_t*)pAddr++) = *pRaw_cur++;
            }
    #endif // defined(CFG_ENABLE_DEBUG_MODE)
        }

        //-------------------------
        // ACK of finish
        hdr.status  = ISP_ACK_OK;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}


static cmd_rst_t
_cmd_page_program(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t      *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        comm_hdr_t      hdr = {0};

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = 4 + CONVERT_LENGTH(pHdr_recv->length);

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        // return ACK
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_SYSTEM_BUSY;
        hdr.length  = 0;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        //-------------------------
        {   // program page
            uint32_t    *pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));
            uint32_t    *pAddr = 0;

            pAddr = (uint32_t*)(*pRaw_cur);

        #if defined(CFG_ENABLE_DEBUG_MODE)
            static uint32_t     *pCur_addr = (uint32_t*)g_debug_mem_poll;
            pAddr = pCur_addr;

            vt_memcpy((void*)pAddr, pRaw_cur + 1, CONVERT_LENGTH(pHdr_recv->length));

            pCur_addr += pHdr_recv->length;
            if( pCur_addr >= (uint32_t*)&g_debug_mem_poll[(sizeof(g_debug_mem_poll) >> 2)] )
                pCur_addr = (uint32_t*)g_debug_mem_poll;
        #endif // defined

        }

        //-------------------------
        // ACK of finish
        hdr.status = ISP_ACK_OK;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));


        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_read_checksum(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t      *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        uint32_t        data_checksum = 0;

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = CONVERT_LENGTH(pHdr_recv->length);

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        {   // calculate sum
            uint32_t    *pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));
            uint32_t    *pAddr = 0;
            uint32_t    len = 0;//pHdr_recv->length;

            pAddr = (uint32_t*)(*pRaw_cur);
            len   = *(pRaw_cur + 1);

        #if defined(CFG_ENABLE_DEBUG_MODE)
            static uint32_t     *pCur_addr = (uint32_t*)g_debug_mem_poll;
            pAddr = pCur_addr;

            pCur_addr += len;

            if( pCur_addr >= (uint32_t*)&g_debug_mem_poll[(sizeof(g_debug_mem_poll) >> 2)] )
                pCur_addr = (uint32_t*)g_debug_mem_poll;
        #endif // defined(CFG_ENABLE_DEBUG_MODE)

            while( len-- > 0 )
            {
                data_checksum += *pAddr++;
            }
        }

        //-------------------------
        // message header
        {
            comm_hdr_t      hdr = {0};
            hdr.cmd     = (g_ack_cmd_value & 0xFF);
            hdr.status  = ISP_ACK_OK;
            hdr.length  = sizeof(data_checksum) >> 2;
            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&hdr, sizeof(hdr));
        }

        // data
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&data_checksum, sizeof(data_checksum));

        //-------------------------
        // check sum
        {
            uint8_t     sum = 0;

            sum = _calc_sum((uint8_t*)&data_checksum, sizeof(data_checksum));

            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&sum, sizeof(sum));
        }

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_vtefc_init(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t          *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        uint32_t            flash_type = (uint32_t)-1;
        comm_hdr_t          hdr = {0};

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = 4;

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        // return ACK
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_SYSTEM_BUSY;
        hdr.length  = 0;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        //---------------------
        {   // TODO: initialize flash
            uint32_t    *pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));

            flash_type = *pRaw_cur;

            if( flash_type > VTEFC_FLASH_TYPE_MXIC_4BIT )
            {
                rval = CMD_RST_NOT_SUPPORT;
                break;
            }

            //test delay
            #if defined(CFG_ENABLE_DEBUG_MODE)
            _delay_sec(5);
            #endif // defined
        }

        //-------------------------
        // ACK of finish
        hdr.status = ISP_ACK_OK;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_get_flash_id(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        uint32_t        factory_id = 0;
        comm_hdr_t      hdr = {0};
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_OK;
        hdr.length  = sizeof(factory_id) >> 2;

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        // get factory id
        #if defined(CFG_ENABLE_DEBUG_MODE)
        factory_id = 0x551234;
        #endif

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&factory_id, sizeof(factory_id));

        //-------------------------
        // check sum
        {
            uint8_t     sum = 0;

            sum = _calc_sum((uint8_t*)&factory_id, sizeof(factory_id));

            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&sum, sizeof(sum));
        }

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_erase(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t          *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        uint32_t            *pRaw_cur = 0;
        uint32_t            address = 0;
        comm_hdr_t          hdr = {0};

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = CONVERT_LENGTH(pHdr_recv->length);

            expected_len += raw_len;

            if( pAttr->cmd != ISP_CMD_ERASE_CHIP )
            {
                rval = _verify_param(pHIsp, pHdr_recv, expected_len);
                if( rval != CMD_RST_DATA_READY )
                    break;

                // verify checksum
                rval = _verify_data(pHIsp, pHdr_recv, raw_len);
                if( rval != CMD_RST_DATA_READY )
                    break;
            }
        }

        //-------------------------
        // return ACK
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_SYSTEM_BUSY;
        hdr.length  = 0;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

#if defined(CONFIG_SIM_MODE)
        comm_dev_reset_buf(pHIsp->pComm_dev, pHIsp->pHComm, NULL, 0);
#endif
        //---------------------
        // TODO: erase flash
        pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));
        address  = *pRaw_cur;

        if( pAttr->cmd == ISP_CMD_ERASE_PAGE )
        {
            // TODO: check address is sector alignment
            uint32_t    page_num = *(pRaw_cur + 1);
            #if defined(CFG_ENABLE_DEBUG_MODE)
            _delay_sec(2);
            #endif // defined
        }
        else if( pAttr->cmd == ISP_CMD_ERASE_CHIP )
        {
            #if defined(CFG_ENABLE_DEBUG_MODE)
            _delay_sec(10);
            #endif // defined
        }
        else if( pAttr->cmd == ISP_CMD_ERASE_SECTOR )
        {
            uint32_t    sector_num = *(pRaw_cur + 1);
            // TODO: check address is sector alignment
            #if defined(CFG_ENABLE_DEBUG_MODE)
            _delay_sec(1);
            #endif // defined
        }
        else if( pAttr->cmd == ISP_CMD_ERASE_BLOCK )
        {
            uint32_t    blk_num = *(pRaw_cur + 1);
            // TODO: check address is sector alignment
            #if defined(CFG_ENABLE_DEBUG_MODE)
            _delay_sec(4);
            #endif // defined
        }

        //-------------------------
        // ACK of erase finish
        hdr.status = ISP_ACK_OK;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_fc_ctrl(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;
    do {
        comm_hdr_t          *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        uint32_t            *pRaw_cur = 0;
        comm_hdr_t          hdr = {0};

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = 4;

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-------------------------
        // return ACK
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_SYSTEM_BUSY;
        hdr.length  = 0;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        //---------------------
        // TODO: control flash
        pRaw_cur = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));
        if( pAttr->cmd == ISP_CMD_PROTECTION )
        {
            if( *pRaw_cur )
            {
                // TODO: protect flash
            }
            else
            {
                // TODO: un-protect flash
            }
        }
        else if( pAttr->cmd == ISP_CMD_QUAD_MODE )
        {
            if( *pRaw_cur )
            {
                // TODO: enable qaud mode
            }
            else
            {
                // TODO: disable qaud mode
            }
        }

        //-------------------------
        // ACK of erase finish
        hdr.status = ISP_ACK_OK;
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_get_remap(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;

    do {
        uint32_t        remap = 0;
        comm_hdr_t      hdr = {0};
        hdr.cmd     = (g_ack_cmd_value & 0xFF);
        hdr.status  = ISP_ACK_OK;
        hdr.length  = sizeof(remap) >> 2;

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&hdr, sizeof(hdr));

        #if defined(CFG_ENABLE_DEBUG_MODE)
        remap = 0x5;
        #endif // defined

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                            (uint8_t*)&remap, sizeof(remap));

        //-------------------------
        // check sum
        {
            uint8_t     sum = 0;

            sum = _calc_sum((uint8_t*)&remap, sizeof(remap));

            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&sum, sizeof(sum));
        }

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_reboot(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    cmd_rst_t   rval = CMD_RST_WAIT_DATA;

    do {
        comm_hdr_t          *pHdr_recv = (comm_hdr_t*)pHIsp->pBuffer;
        uint32_t            *pRaw_cur = 0;
        uint32_t            remap_type = 0;

        {
            int             expected_len = sizeof(comm_hdr_t) + 1;
            int             raw_len = 4;

            expected_len += raw_len;

            rval = _verify_param(pHIsp, pHdr_recv, expected_len);
            if( rval != CMD_RST_DATA_READY )
                break;

            // verify checksum
            rval = _verify_data(pHIsp, pHdr_recv, raw_len);
            if( rval != CMD_RST_DATA_READY )
                break;
        }

        //-----------------------------
        // TODO: trigger watch dog to reboot
        pRaw_cur   = (uint32_t*)((uint32_t)pHIsp->pBuffer + sizeof(comm_hdr_t));
        remap_type = *pRaw_cur;


    #if defined(CFG_ENABLE_DEBUG_MODE)
        char    *pBuf = (char*)g_buf;
        char    *pCur = pBuf;

        // simulate reboot delay
        _delay_sec(5);

        vt_strcpy(pBuf, CONFIG_SYSTEM_BANNER_P);
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm, (uint8_t*)pBuf, vt_strlen(pBuf));

        *pCur++ = 'v';
        *pCur++ = CONFIG_VERSION_B + 0x30;
        *pCur++ = '.';
        *pCur++ = (CONFIG_VERSION_C / 10) + 0x30;
        *pCur++ = (CONFIG_VERSION_C % 10) + 0x30;
        *pCur++ = '.';
        *pCur++ = (CONFIG_VERSION_D / 10) + 0x30;
        *pCur++ = (CONFIG_VERSION_D % 10) + 0x30;
        *pCur++ = '\0';

        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm, (uint8_t*)pBuf, vt_strlen(pBuf));

        vt_strcpy(pBuf, CONFIG_SYSTEM_BANNER_S);
        comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm, (uint8_t*)pBuf, vt_strlen(pBuf));
    #endif // defined

        rval = CMD_RST_FINISH;
    } while(0);
    return rval;
}

static cmd_rst_t
_cmd_ping_old(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    g_ack_cmd_value = ISP_CMD_ACK_OLD;
    return _cmd_ping(pHIsp, pAttr);
}

static cmd_rst_t
_cmd_word_read_old(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    g_ack_cmd_value = ISP_CMD_ACK_OLD;
    return _cmd_read_4bytes(pHIsp, pAttr);
}

static cmd_rst_t
_cmd_word_write_old(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    g_ack_cmd_value = ISP_CMD_ACK_OLD;
    return _cmd_write_4bytes(pHIsp, pAttr);
}

static cmd_rst_t
_cmd_page_program_old(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    g_ack_cmd_value = ISP_CMD_ACK_OLD;
    return _cmd_page_program(pHIsp, pAttr);
}

static cmd_rst_t
_cmd_read_checksum_old(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    g_ack_cmd_value = ISP_CMD_ACK_OLD;
    return _cmd_read_checksum(pHIsp, pAttr);
}

static cmd_rst_t
_cmd_vtefc_init_old(isp_handle_t *pHIsp, isp_cmd_attr_t *pAttr)
{
    g_ack_cmd_value = ISP_CMD_ACK_OLD;
    return _cmd_vtefc_init(pHIsp, pAttr);
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
static isp_cmd_attr_t       g_isp_cmds[] =
{
    { ISP_CMD_WRITE_DATA,         _cmd_write_data },
    { ISP_CMD_READ_CHECKSUM,      _cmd_read_checksum },
    { ISP_CMD_WRITE_DMA,          _cmd_default },
    { ISP_CMD_PROTECTION,         _cmd_fc_ctrl },
    { ISP_CMD_PAGE_PROGRAM,       _cmd_page_program },
    { ISP_CMD_ERASE_PAGE,         _cmd_erase },
    { ISP_CMD_READ_4BYTES,        _cmd_read_4bytes },
    { ISP_CMD_WRITE_4BYTES,       _cmd_write_4bytes },
    { ISP_CMD_VTEFC_INIT,         _cmd_vtefc_init },
    { ISP_CMD_ERASE_SECTOR,       _cmd_erase },
    { ISP_CMD_ERASE_BLOCK,        _cmd_erase },
    { ISP_CMD_ERASE_CHIP,         _cmd_erase },
    { ISP_CMD_QUAD_MODE,          _cmd_fc_ctrl },
    { ISP_CMD_GET_FLASH_ID,       _cmd_get_flash_id },
    { ISP_CMD_GET_REMAP,          _cmd_get_remap },
    { ISP_CMD_SETUP,              _cmd_default },
    { ISP_CMD_PING,               _cmd_ping },
    { ISP_CMD_REBOOT,             _cmd_reboot },
    { ISP_CMD_PING_OLD,           _cmd_ping_old },
    { ISP_CMD_WORD_READ_OLD,      _cmd_word_read_old },
    { ISP_CMD_WORD_WRITE_OLD,     _cmd_word_write_old },
    { ISP_CMD_READ_CHECKSUM_OLD,  _cmd_read_checksum_old },
    { ISP_CMD_PAGE_PROGRAM_OLD,   _cmd_page_program_old },
    { ISP_CMD_VTEFC_INIT_OLD,     _cmd_vtefc_init_old },
};

void
isp_proc(
    isp_handle_t    *pHIsp)
{
    static int  cmd_cnt = sizeof(g_isp_cmds) / sizeof(g_isp_cmds[0]);

#if defined(CFG_ENABLE_DEBUG_MODE)
    static int  g_is_init = 0;
    if( g_is_init == 0 )
    {
        for(int i = 0; i < (sizeof(g_debug_mem_poll) >> 2); i++)
        {
            g_debug_mem_poll[i] = (i + 1) & 0xFF;
        }

        g_is_init = 1;
    }
#endif // defined(CFG_ENABLE_DEBUG_MODE)

    do {
        int             i = 0;
        cmd_rst_t       rval = CMD_RST_FINISH;

        if( pHIsp->pHComm == 0 || pHIsp->pComm_dev == 0 )
            break;

        if( comm_dev_get_state(pHIsp->pComm_dev, pHIsp->pHComm,
                               COMM_STATE_GET_RX_EVENT) == 0 )
            break;

        if( pHIsp->pBuffer == 0 )   break;

        //-------------------------------
        {   // receive data
            int     remain = pHIsp->buffer_len - pHIsp->valid_len;
            comm_dev_recv_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                &pHIsp->pBuffer[pHIsp->valid_len], &remain);

            // recv_bytes() will return the valid length
            pHIsp->valid_len += remain;
        }

        if( pHIsp->valid_len < sizeof(comm_hdr_t) )  break;

        //-------------------------------
        // check command and do the mapping method
        for(i = 0; i < cmd_cnt; ++i)
        {
            if( g_isp_cmds[i].cmd == (ISP_CMD_t)pHIsp->pBuffer[0] )
            {
                if( g_isp_cmds[i].cmd_handler )
                {
                    g_ack_cmd_value = ISP_CMD_ACK;
                    rval = g_isp_cmds[i].cmd_handler(pHIsp, &g_isp_cmds[i]);
                }
                break;
            }
        }

        if( i == cmd_cnt )
            rval = CMD_RST_NOT_SUPPORT;

        //--------------------------
        // handle result
        if( rval == CMD_RST_FINISH )
        {
            pHIsp->valid_len = 0;   // reset for next commands
            pHIsp->timeout   = ISP_CMD_RECV_TIMEOUT;

            comm_dev_reset_buf(pHIsp->pComm_dev, pHIsp->pHComm, NULL, 0);
        }
        else if( (rval & 0xF0) == 0xE0 )
        {
            comm_hdr_t      hdr = {0};

            hdr.cmd     = (g_ack_cmd_value & 0xFF);
            hdr.status  = rval;
            hdr.length  = 0;

            comm_dev_send_bytes(pHIsp->pComm_dev, pHIsp->pHComm,
                                (uint8_t*)&hdr, sizeof(hdr));

            pHIsp->valid_len = 0; // reset for next commands
            pHIsp->timeout   = ISP_CMD_RECV_TIMEOUT;

            comm_dev_reset_buf(pHIsp->pComm_dev, pHIsp->pHComm, NULL, 0);
        }
    } while(0);
    return;
}


#if defined(CONFIG_SIM_MODE)
#include <windows.h>
#include "pthread.h"

static isp_handle_t     g_hIsp = {.pComm_dev = 0,};
static uint32_t         g_consol_0_msg_buf[(CONFIG_FLASH_PAGE_LENGTH + 20) >> 2] = {0};

extern comm_desc_t      g_comm_desc_rom_sim;

void*
task_rom_code(void *argv)
{
    int             *pIs_running = (int*)argv;
    comm_desc_t     *pComm_dev = &g_comm_desc_rom_sim;
    isp_handle_t    *pHIsp = 0;

    pthread_detach(pthread_self());


    {   // initial comm device
        comm_cfg_t      cfg = {.pBuf = 0,};

        cfg.uart.port       = CONFIG_CONSOLE_0_PORT;
        cfg.uart.baud_rate  = CONFIG_CONSOLE_0_BAUDRATE;
        cfg.pBuf 			= (uint8_t*)g_consol_0_msg_buf;
        cfg.buf_len  	    = sizeof(g_consol_0_msg_buf);

        pHIsp = &g_hIsp;

        pHIsp->pHComm    = comm_dev_init(pComm_dev, &cfg);
        pHIsp->pComm_dev = pComm_dev;
        pHIsp->valid_len = 0;
        pHIsp->timeout   = ISP_CMD_RECV_TIMEOUT;

        // TODO: assign buffer pool for receiving command message
        pHIsp->pBuffer    = (uint8_t*)g_consol_0_msg_buf;
        pHIsp->buffer_len = sizeof(g_consol_0_msg_buf);
    }

    while( *pIs_running )
    {
        isp_proc(&g_hIsp);
        Sleep(100);
    }

    pthread_exit(0);
    return 0;
}
#endif // defined



