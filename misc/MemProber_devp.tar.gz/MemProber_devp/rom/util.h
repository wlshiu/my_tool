/**
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 */
/** @file util.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/12
 * @license
 * @description
 */


#ifndef __util_H_w413deaa_lf73_hedd_sd2b_uf627f708e66__
#define __util_H_w413deaa_lf73_hedd_sd2b_uf627f708e66__

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>
#include "sys_config.h"
//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================
#ifndef MIN
    #define MIN(a, b)                           (((a) < (b)) ? (a) : (b))
#endif

#ifndef MAX
    #define MAX(a, b)                           (((a) > (b)) ? (a) : (b))
#endif


#define stringize(s)    #s
#define _toStr(a)       stringize(a)

#define FOUR_CC(a, b, c, d)         (((a) << 24) | ((b) << 16) | ((c) << 8) | (d))

#if 1 // debug
    #define _assert(expr) ((expr) ? (void)0 : assert_failed(__func__, __LINE__, _toStr(expr)))
    /* Exported functions ------------------------------------------------------- */
    void assert_failed(const char *func_name, uint32_t line, char *expr);
#else
    #define _assert(x)
#endif // 1

#if defined(__GNUC__)
extern char     __text_start__;
extern char     __text_end__;

extern char     __bss_start__;
extern char     __bss_end__;

extern char     __data_start__;
extern char     __data_end__;

extern char     __HeapBase;
extern char     __HeapLimit;

extern char     __StackTop;
extern char     __StackLimit;

#define GET_STACK_START(ppAddr)      (*(ppAddr) = &__StackTop)
#define GET_STACK_END(ppAddr)        (*(ppAddr) = &__StackLimit)
#define GET_HEAP_START(ppAddr)       (*(ppAddr) = &__HeapBase)
#define GET_HEAP_END(ppAddr)         (*(ppAddr) = &__HeapLimit)

#endif
//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
#if (CONFIG_USE_STD_LIBC)
    #define vt_strlen       strlen
    #define vt_strcpy       strcpy
    #define vt_memcpy       memcpy
#else   // #if (CONFIG_USE_STD_LIBC)
size_t
vt_strlen(const char* str);

char*
vt_strcpy(char *dest, const char *src);

void*
vt_memcpy(unsigned char* to, unsigned char* from, int count);

#endif  // #if (CONFIG_USE_STD_LIBC)


#ifdef __cplusplus
}
#endif

#endif


