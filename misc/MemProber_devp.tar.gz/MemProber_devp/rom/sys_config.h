/*
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 *
 */

#ifndef __SYS_CONFIG_INC__
#define __SYS_CONFIG_INC__

#ifdef __cplusplus
extern "C" {
#endif

//=============================================================================
//                  version
//=============================================================================
#define CONFIG_VERSION_A                    0xff        // [region] 0xff) internal engineering
#define CONFIG_VERSION_B                    0           // major
#define CONFIG_VERSION_C                    0           // minor
#define CONFIG_VERSION_D                    0           // release

#define CONFIG_BUILD_TIME

// ---------------------------------------------------------------------------
// Following are architecture-specific configuration fields ...
//

//=============================================================================
//                  sys tick counter
//=============================================================================
#define CONFIG_SYSTICK_ENABLE               0
#define CONFIG_SYSTICK_TIMER                0
// #define CONFIG_SYSTICK_RATE_HZ              1000

//=============================================================================
//                  system interrupt
//=============================================================================
/**
 *  non-zero to enable FTINTC vector mode irq support
 */
#define CONFIG_IRQ_VECTOR_MODE              1


/**
 *  non-zero to enable support of exception info dump
 *  when any unhandled exeption gets asserted
 */
#define CONFIG_EXCEPTION_INFO               1


//=============================================================================
//                  serial console
//=============================================================================
#define CONFIG_CONSOLE_0_PORT                 0
#define CONFIG_CONSOLE_0_BAUDRATE             115200

#define CONFIG_CONSOLE_1_PORT                 0
#define CONFIG_CONSOLE_1_BAUDRATE             115200

#define CONFIG_CONSOLE_SWFIFO_DEPTH         16

#define CONFIG_SHOW_SYSTEM_BANNER           1
#define CONFIG_SYSTEM_BANNER_P              "\r\n\r\nPhoenix ROM "
#define CONFIG_SYSTEM_BANNER_S              " Copyright (c) 2019 Vango Technologies, Inc.\r\n"

//=============================================================================
//                  spi interface
//=============================================================================
#define CONFIG_SPI_DEFAULT_MASTER_DATA_RATE 1600000
#define CONFIG_SPI_DEFAULT_SLAVE_DATA_RATE  1600000

//=============================================================================
//                  ahb-lite dmac
//=============================================================================
#define CONFIG_FTDMAC_INTERRUPT_SUPPORT     0

//=============================================================================
//                  flash setting
//=============================================================================
#define CONFIG_FLASH_PAGE_LENGTH            256



#ifdef __cplusplus
}
#endif

#endif /* __SYS_CONFIG_INC__ */

