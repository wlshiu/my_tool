/*
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 *
 */
/** @file isp.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/11
 * @license
 * @description
 */


#ifndef __isp_H_wf629037_lfbf_h788_s413_u45dbe0f72a1__
#define __isp_H_wf629037_lfbf_h788_s413_u45dbe0f72a1__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "comm_desc.h"

//=============================================================================
//                  Constant Definition
//=============================================================================
#define ISP_CMD_RECV_TIMEOUT        (65536 << 1)

typedef enum ISP_CMD
{
    /**
     *  hint: 0x00 && 0xff is not suitable for command encoding since the default
     *  state on the data bus is either 0x00 or 0xff and could be a garbage data
     *  if the master and slave state-switch is out of sync.
     */
    ISP_CMD_PING          = 0x0F,
    ISP_CMD_ACK           = 0xF0,
    ISP_CMD_REBOOT        = 0xF5,

    // read
    ISP_CMD_READ_4BYTES   = 0x11,
    ISP_CMD_READ_CHECKSUM = 0x12,

    // write
    ISP_CMD_WRITE_DMA     = 0x51,
    ISP_CMD_WRITE_4BYTES  = 0x52,
    ISP_CMD_WRITE_DATA    = 0x53,

    // flash control
    ISP_CMD_GET_FLASH_ID  = 0x90,
    ISP_CMD_PAGE_PROGRAM  = 0x91,
    ISP_CMD_VTEFC_INIT    = 0x92,
    ISP_CMD_ERASE_SECTOR  = 0x93,
    ISP_CMD_ERASE_PAGE    = 0x94,
    ISP_CMD_ERASE_BLOCK   = 0x95,
    ISP_CMD_ERASE_CHIP    = 0x96,
    ISP_CMD_QUAD_MODE     = 0x97,
    ISP_CMD_PROTECTION    = 0x98,

    // misc
    ISP_CMD_GET_REMAP     = 0xC1,
    ISP_CMD_SETUP         = 0xC2,
    ISP_CMD_BREAK         = 0xCC,

    // FIXME: the old version ghost
    ISP_CMD_PING_OLD          = 0x00,
    ISP_CMD_ACK_OLD           = 0xFF,
    ISP_CMD_WORD_READ_OLD     = 0x01, // common sense: "a word == 2 bytes", but here "a word == 4 bytes" (WTF !!!)
    ISP_CMD_WORD_WRITE_OLD    = 0x02, // common sense: "a word == 2 bytes", but here "a word == 4 bytes" (WTF !!!)
    ISP_CMD_READ_CHECKSUM_OLD = 0x03, // return the checksum of all data
    ISP_CMD_PAGE_PROGRAM_OLD  = 0x05,
    ISP_CMD_VTEFC_INIT_OLD    = 0x06,

} ISP_CMD_t;

typedef enum ISP_ACK_STATUS
{
    ISP_ACK_OK                  = 0x00,
    ISP_ACK_UNKNOWN             = 0xE0,  // unknown command
    ISP_ACK_MISCHECKSUM         = 0xE1,  // checksum mis-match
    ISP_ACK_TIMEOUT             = 0xE2,
    ISP_ACK_OUT_BUF_LEN         = 0xE3,
    ISP_ACK_NOT_SUPPORT         = 0xE4,
    ISP_ACK_VERSION_NOT_MATCH   = 0xE5,
    ISP_ACK_ADDR_NOT_ALIGNMENT  = 0xE6,
    ISP_ACK_SYSTEM_BUSY         = 0xE7,

} ISP_ACK_STATUS_t;
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct isp_handle
{
    comm_desc_t     *pComm_dev;
    comm_handle_t   pHComm;

    uint32_t        valid_len;
    uint32_t        buffer_len;
    uint8_t         *pBuffer;

    int             timeout;

} isp_handle_t;

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
void
isp_proc(
    isp_handle_t    *pHIsp);


#ifdef __cplusplus
}
#endif

#endif


