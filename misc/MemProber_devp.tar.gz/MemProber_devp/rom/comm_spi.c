/**
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 */
/** @file comm_spi.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/12
 * @license
 * @description
 */



#include <stdbool.h>
#include "comm_desc.h"
#include "phoenix_periph.h"
#include "util.h"

//=============================================================================
//                  Constant Definition
//=============================================================================
//#define CFG_USE_PRIVATE_BUF

#define UART_BUFFER_LENGTH      64 // it MUST power of 2


//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct spi_dev
{
    uint16_t            is_used;
    uint16_t            has_rx_event;
    SPI_TypeDef         *pHSpi;

    volatile uint16_t   rd_idx;
    volatile uint16_t   wr_idx;

#if defined(CFG_USE_PRIVATE_BUF)
    uint8_t             pRx_buf[SPI_BUFFER_LENGTH];
#else
    uint8_t             *pRx_buf;
    uint32_t            rx_buf_len;
#endif
} spi_dev_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
static spi_dev_t    g_spi_dev = {0};
//=============================================================================
//                  Private Function Definition
//=============================================================================
void SSP1_IRQHandler(void)
{
    spi_dev_t   *pDev = &g_spi_dev;
    uint32_t    rd_idx = pDev->rd_idx;
    uint32_t    wr_idx = pDev->wr_idx;
    uint32_t    pos = 0;

#if defined(CFG_USE_PRIVATE_BUF)
    pos = (wr_idx + 1) & (SPI_BUFFER_LENGTH - 1);
#else
    pos = (wr_idx + 1) % pDev->rx_buf_len;
#endif

    if( pos == rd_idx )
    {
        // buffer full checking
        while(1)
            __asm("nop");
    }

    pDev->pRx_buf[wr_idx] = SPI_ReceiveData(pDev->pHSpi);
    pDev->wr_idx          = pos;
    pDev->has_rx_event    = (uint16_t)true;
    return;
}

static comm_handle_t
_spi_init(comm_cfg_t *pCfg)
{
    spi_dev_t          *pSpi_dev = 0;

    do {
        SPI_InitTypeDef    spi_setting = {0};

        pSpi_dev = &g_spi_dev;
        pSpi_dev->is_used = true;
        pSpi_dev->pHSpi   = SSP1; // SPI_1: slave, SPI_0: master
        pSpi_dev->wr_idx  = 0;
        pSpi_dev->rd_idx  = 0;

        #if !defined(CFG_USE_PRIVATE_BUF)
        pSpi_dev->pRx_buf    = pCfg->pBuf;
        pSpi_dev->rx_buf_len = pCfg->buf_len;
        #endif

        /* SPI_MASTER configuration ------------------------------------------------*/
        spi_setting.SPI_Direction         = SPI_Direction_2Lines_FullDuplex; // SPI_Direction_1Line_Rx
        spi_setting.SPI_Mode              = SPI_Mode_Slave;
        spi_setting.SPI_DataSize          = SPI_DataSize_8b;
        spi_setting.SPI_CPOL              = SPI_CPOL_Low;
        spi_setting.SPI_CPHA              = SPI_CPHA_2Edge;
        spi_setting.SPI_NSS               = 0;  //SPI_NSS_Soft;
        spi_setting.SPI_BaudRatePrescaler = 100*1000; //SPI_BaudRatePrescaler_8;
        spi_setting.SPI_FirstBit          = SPI_FirstBit_MSB;
        spi_setting.SPI_CRCPolynomial     = 0; //CRCPolynomial

        SPI_Init(pSpi_dev->pHSpi, &spi_setting);
        SPI_ITConfig(pSpi_dev->pHSpi,
                    SPI_ICR_RFOR | SPI_ICR_TFUR | SPI_ICR_RFTH | SPI_ICR_TFTH,
                    ENABLE);
        SPI_Cmd(pSpi_dev->pHSpi, SPI_CR2_SSPEN);


        NVIC_EnableIRQ(SSP0_IRQn);
        NVIC_ClearPendingIRQ(SSP0_IRQn);
    } while(0);

    return (comm_handle_t)pSpi_dev;
}

static int
_spi_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    int     rval = 0;
    do {
        spi_dev_t   *pSpi_dev = (spi_dev_t*)pHandle;
        int         i = 0;

        if( pHandle == 0 || pData == 0 || data_len == 0 )
        {
            rval = -1;
            break;
        }

        while( i < data_len )
        {
            // TODO: check the sent byte data is finish (timerout is necessary if no clock from master)
            SPI_SendData(pSpi_dev->pHSpi, *((volatile uint8_t*)(pData + i)));
            i++;
        }

    } while(0);
    return rval;
}

static int
_spi_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    int     rval = 0;
    do {
        spi_dev_t   *pSpi_dev = (spi_dev_t*)pHandle;
        int         len = 0;
        int         rd_idx = pSpi_dev->rd_idx;
        int         wr_idx = pSpi_dev->wr_idx;

        if( pHandle == 0 )
        {
            rval = -1;
            break;
        }

        while( 1 )
        {
            if( rd_idx == wr_idx )      break;
            if( *pData_len == len )     break;

        #if defined(CFG_USE_PRIVATE_BUF)
            *pData++ = pSpi_dev->rx_buf[rd_idx];
            rd_idx = (rd_idx + 1) & (SPI_BUFFER_LENGTH - 1);
        #else
            rd_idx = (rd_idx + 1) % pSpi_dev->rx_buf_len;
        #endif // defined

            len++ ;
        }

        pSpi_dev->rd_idx = rd_idx;

        *pData_len = len;

    } while(0);
    return rval;
}

static int
_spi_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
    spi_dev_t       *pSpi_dev = (spi_dev_t*)pHandle;

    if( pHandle == 0 )  return -1;

    if( state == COMM_STATE_GET_RX_EVENT )
    {
        uint32_t    rd_idx = pSpi_dev->rd_idx;
        uint32_t    wr_idx = pSpi_dev->wr_idx;
        // if empty, no rx_event
        rval = !(rd_idx == wr_idx);
    }

    return rval;
}

static int
_spi_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
        spi_dev_t       *pSpi_dev = (spi_dev_t*)pHandle;

        if( pHandle == 0 )
        {
            rval = -1;
            break;
        }
#if !defined(CFG_USE_PRIVATE_BUF)
        pSpi_dev->rd_idx = 0;
        pSpi_dev->wr_idx = 0;

        if( pBuf && buf_len )
        {
            pSpi_dev->pRx_buf    = pBuf;
            pSpi_dev->rx_buf_len = buf_len;
        }
#endif
    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_desc_t     g_comm_spi =
{
    .init       = _spi_init,
    .send_bytes = _spi_send_bytes,
    .recv_bytes = _spi_recv_bytes,
    .get_state  = _spi_get_state,
    .reset_buf  = _spi_reset_buf,
};




