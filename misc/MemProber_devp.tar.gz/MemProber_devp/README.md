MemProber
---

+ dependency

    ```shell
    $ sudo apt-get -y install automake autoconf libtool
    ```

+ build code

    ```shell
    $ ./configure
    $ make
    ```
