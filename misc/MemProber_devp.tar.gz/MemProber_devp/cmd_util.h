/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file cmd_util.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/18
 * @license
 * @description
 */


#ifndef __cmd_util_H_7d3a3e06_1c02_450d_b7ba_19da2643e9ff__
#define __cmd_util_H_7d3a3e06_1c02_450d_b7ba_19da2643e9ff__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
//=============================================================================
//                  Constant Definition
//=============================================================================
typedef enum cmd_flag
{
    CMD_FLAG_OPTION_TYPE    = (0X1 << 0),
    CMD_FLAG_COMMAND_TYPE   = (0X1 << 1),
} cmd_flag_t;
//=============================================================================
//                  Macro Definition
//=============================================================================
#define _str2int(str)        (str[1] == 'x' || str[1] == 'X') \
                                ? strtoul(&str[2], 0, 16) : strtoul(&str[0], 0, 10)


//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct cmd_item
{
    char        *pCmd_name;
    uint32_t    uid;
    int         argument_cnt;
    uint32_t    flags;
    char        *pDescription;

    void    *pTunnel_info;
    int     (*pf_cmd_handler)(struct cmd_item *pCmd_item, char **argv, void *pTunnel_info);

} cmd_item_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
int
cmd_util_init(void);

int
cmd_util_register(
    cmd_item_t  *pCmd_itm);


int
cmd_util_parse_args(int argc, char **argv);


void
cmd_util_dump_description(void);


#ifdef __cplusplus
}
#endif

#endif


