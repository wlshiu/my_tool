/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file cmd_util.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/18
 * @license
 * @description
 */



#include <string.h>
#include "cmd_util.h"
#include "log.h"
#include "global.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#define CMD_MAX_NUM         100
//=============================================================================
//                  Macro Definition
//=============================================================================
#define _str_to_int(str)    ((str[1] == 'x' || str[1] == 'X') ? \
                                strtoul(&str[2], 0, 16) : strtoul(&str[0], 0, 10))
//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================
static cmd_item_t       *g_pCmd_list[CMD_MAX_NUM];
//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
int
cmd_util_init(void)
{
    memset(g_pCmd_list, 0x0, sizeof(cmd_item_t*)*CMD_MAX_NUM);
    return 0;
}

int
cmd_util_register(
    cmd_item_t  *pCmd_itm)
{
    int         rval = 0;
    cmd_item_t  **ppAct_itm = 0;

    // search a empty slot
    for(int i = 0; i < CMD_MAX_NUM; i++)
    {
        if( !g_pCmd_list[i] )
        {
            ppAct_itm = &g_pCmd_list[i];
            break;
        }

        if( !strcmp(g_pCmd_list[i]->pCmd_name, pCmd_itm->pCmd_name) )
        {
            err("cmd is exist %s\n", pCmd_itm->pCmd_name);
            rval = -1;
            break;
        }
    }

    // assign cmd_item to slot
    if( ppAct_itm )
        *ppAct_itm = pCmd_itm;

    return rval;
}


int
cmd_util_parse_args(int argc, char **argv)
{
    int     rval = 0;

    if( argc < 4 )      return -1;

    argv++; argc--;
    while( argc )
    {
        for(int i = 0; i < CMD_MAX_NUM; i++)
        {
            if( !strcmp(argv[0], g_pCmd_list[i]->pCmd_name) )
            {
                cmd_item_t      *pCur = g_pCmd_list[i];
                if( pCur->pf_cmd_handler )
                    rval = pCur->pf_cmd_handler(pCur, argv, pCur->pTunnel_info);

                argv += (pCur->argument_cnt + 1);
                argc -= (pCur->argument_cnt + 1);
                break;
            }
        }

        if( rval )  break;
    }
    return rval;
}

void
cmd_util_dump_description(void)
{
    // dump CMD_FLAG_OPTION_TYPE
    for(int i = 0; i < CMD_MAX_NUM; i++)
    {
        cmd_item_t      *pCur = g_pCmd_list[i];
        if( !pCur )
            continue;

        if( pCur->flags & CMD_FLAG_OPTION_TYPE )
        {
            fprintf(stderr, "options:  %s%s%s\n",
                    pCur->pCmd_name,
                    (pCur->argument_cnt) ? " ": "\n",
                    pCur->pDescription);
        }
    }

    // dump CMD_FLAG_COMMAND_TYPE
    for(int i = 0; i < CMD_MAX_NUM; i++)
    {
        cmd_item_t      *pCur = g_pCmd_list[i];
        if( !pCur )
            continue;

        if( pCur->flags & CMD_FLAG_COMMAND_TYPE )
        {
            fprintf(stderr, "commands:  %s%s%s\n",
                    pCur->pCmd_name,
                    (pCur->argument_cnt) ? " ": "\n",
                    pCur->pDescription);
        }
    }
    fflush(stderr);
    return;
}


