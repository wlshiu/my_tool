/**
 * Copyright (c) 2020 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file comm_dev_uart_win.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2020/03/11
 * @license
 * @description
 */

#if defined(__WIN32__) || defined(_WIN32)
#include <windows.h>
#include <unistd.h>         //Used for UART
//=============================================================================
//                  Constant Definition
//=============================================================================
#define CONFIG_UART_RX_BUF_POW2             14
#define CONFIG_UART_RX_BUF_SIZE             (0x1 << CONFIG_UART_RX_BUF_POW2)
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct uart_dev
{
    HANDLE              fd_uart;
    volatile uint16_t   rd_idx;
    volatile uint16_t   wr_idx;

    int                 is_rx_running;
    uint8_t             *pRx_buf;
    long                rx_buf_len;
    comm_dev_type_t     dev_type;
} uart_dev_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
static uint8_t      g_rx_buf[CONFIG_UART_RX_BUF_SIZE] = {0};

static uart_dev_t   g_uart_dev = {};
//=============================================================================
//                  Private Function Definition
//=============================================================================
static uint32_t __stdcall
_win_uart_data_listener(PVOID pM)
{
    uart_dev_t   *pDev = (uart_dev_t*)pM;

    msg(LOG_LEVEL_INFO, "_uart_data_listener start\n");

    pDev->is_rx_running = true;

    while( pDev->is_rx_running )
    {
        DWORD       len = 0;
        uint32_t    rd_idx = pDev->rd_idx;
        uint32_t    wr_idx = pDev->wr_idx;
        uint32_t    pos = 0;

        pos = (wr_idx + 1) & (pDev->rx_buf_len - 1);
        if( pos == rd_idx )
        {
            usleep(5000);
            continue;
        }

        ReadFile(pDev->fd_uart,               // Handle of the Serial port
                 &pDev->pRx_buf[wr_idx],      // Temporary character
                 (pDev->rx_buf_len - wr_idx), // Size of TempChar
                 &len,                        // Number of bytes read
                 NULL);

        if( len < 0 )
        {
            err("uart read fail\n");
        }
        else if( len )
        {
            wr_idx += len;
            pDev->wr_idx = (uint16_t)wr_idx;
        }
        else    usleep(10);
    }

    return 0;
}

static comm_handle_t
_win_uart_init(comm_cfg_t *pCfg)
{
    uart_dev_t     *pHDev = 0;
    do {
        DCB         dcbSerialParams = {}; // Initializing DCB structure
        HANDLE      uart_rx_handler;
        COMMTIMEOUTS CommTimeouts = {};
        char        UartName[100];
        CHAR        *pcCommPort;
        BOOL fSuccess;

        sprintf((char *)UartName, "\\\\.\\%s", (const char *)pCfg->pDev_name);
        msg(LOG_LEVEL_INFO, "uart %s init\n", UartName);
        pcCommPort = UartName;
        g_uart_dev.fd_uart = CreateFile(pcCommPort,                     //port name
                                        GENERIC_READ | GENERIC_WRITE,   //Read/Write
                                        0,                              // No Sharing
                                        NULL,                           // No Security
                                        OPEN_EXISTING,                  // Open existing port only
                                        FILE_ATTRIBUTE_NORMAL,
                                        NULL);                          // Null for Comm Devices

        if( g_uart_dev.fd_uart == INVALID_HANDLE_VALUE )
        {
            msg(LOG_LEVEL_INFO, "uart creat fail\n");
            break;
        }

        g_uart_dev.is_rx_running = false;
        g_uart_dev.dev_type      = COMM_DEV_TYPE_UART;
        g_uart_dev.pRx_buf       = g_rx_buf;
        g_uart_dev.rx_buf_len    = sizeof(g_rx_buf);
        uart_rx_handler = CreateThread(NULL,       // default security attributes
                                       0,          // use default stack size
                                       (LPTHREAD_START_ROUTINE)_uart_data_listener,         // thread function name
                                       (void*)&g_uart_dev,       // argument to thread function
                                       0,          // use default creation flags
                                       NULL);      // returns the th

        if (uart_rx_handler == NULL)
        {
            msg(LOG_LEVEL_INFO, "CreateThread fail\n");
            break;
        }

        dcbSerialParams.DCBlength = sizeof(DCB);

        fSuccess = GetCommState(g_uart_dev.fd_uart, &dcbSerialParams);

        if (!fSuccess)
        {
            //  Handle the error.
            msg(LOG_LEVEL_INFO, "GetCommState failed with error %d.\n", GetLastError());
            return(NULL);
        }

        //  Fill in some DCB values and set the com state:
        //  57,600 bps, 8 data bits, no parity, and 1 stop bit.
        dcbSerialParams.BaudRate = CBR_115200;  //  baud rate
        dcbSerialParams.ByteSize = 8;           //  data size, xmit and rcv
        dcbSerialParams.Parity = NOPARITY;      //  parity bit
        dcbSerialParams.StopBits = ONESTOPBIT;  //  stop bit
        dcbSerialParams.fBinary = 0;            // force binary mode
        dcbSerialParams.fParity = 0;            // no parity check

        dcbSerialParams.fOutxCtsFlow = 0;    // Disable CTS monitoring
        dcbSerialParams.fOutxDsrFlow = 0;    // Disable DSR monitoring
        dcbSerialParams.fDtrControl = 0;     // Disable DTR monitoring
        dcbSerialParams.fOutX = 0;           // Disable XON/XOFF for transmission
        dcbSerialParams.fInX = 0;            // Disable XON/XOFF for receiving
        dcbSerialParams.fRtsControl = 0;     // Disable RTS (Ready To Send)
        dcbSerialParams.fDsrSensitivity = 0;
        dcbSerialParams.fNull = 0;

        fSuccess = SetCommState(g_uart_dev.fd_uart, &dcbSerialParams);
        if (!fSuccess)
        {
            //  Handle the error.
            msg(LOG_LEVEL_INFO, "SetCommState failed with error %d.\n", GetLastError());
            return(NULL);
        }

        //  Get the comm config again.
        fSuccess = GetCommState(g_uart_dev.fd_uart, &dcbSerialParams);

        if (!fSuccess)
        {
            //  Handle the error.
            msg(LOG_LEVEL_INFO, "GetCommState failed with error %d.\n", GetLastError());
            return(NULL);
        }

        fSuccess = GetCommTimeouts(g_uart_dev.fd_uart, &CommTimeouts);
        if (!fSuccess)
        {
            //  Handle the error.
            msg(LOG_LEVEL_INFO, "GetCommTimeouts failed with error %d.\n", GetLastError());
            return(NULL);
        }

        CommTimeouts.ReadIntervalTimeout = -1;
        CommTimeouts.ReadTotalTimeoutConstant = 0;
        CommTimeouts.ReadTotalTimeoutMultiplier = 0;
        CommTimeouts.WriteTotalTimeoutConstant = 500;
        CommTimeouts.WriteTotalTimeoutMultiplier = 0;

        fSuccess = SetCommTimeouts(g_uart_dev.fd_uart, &CommTimeouts);
        if (!fSuccess)
        {
            //  Handle the error.
            msg(LOG_LEVEL_INFO, "SetCommTimeouts failed with error %d.\n", GetLastError());
            return(NULL);
        }
        pHDev = &g_uart_dev;
    } while(0);

    return (comm_handle_t)pHDev;
}

static int
_win_uart_deinit(comm_handle_t pHandle)
{
    int     rval = 0;
    do {
        uart_dev_t     *pHDev = (uart_dev_t*)pHandle;

        if( !pHDev )   break;

        pHDev->is_rx_running = false;

        usleep(10000);

        CloseHandle(pHDev->fd_uart);    // Closing the Serial Port
        memset(&g_uart_dev, 0x0, sizeof(g_uart_dev));
    } while(0);

    return rval;
}

static int
_win_uart_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    int     rval = 0;
    do {
        uart_dev_t     *pHDev = (uart_dev_t*)pHandle;
        int             count = 0;
        DWORD           dNoOfBytesWritten = 0;     // No of bytes written to the port

        if( !pHDev )   break;

        count = WriteFile(pHDev->fd_uart,       // Handle to the Serial port
                          pData,                // Data to be written to the port
                          data_len,             //No of bytes to write
                          &dNoOfBytesWritten,   //Bytes written
                          NULL);
        if( dNoOfBytesWritten < 0 || (dNoOfBytesWritten != data_len) )
            rval = -1;
    } while(0);
    return rval;
}

static int
_win_uart_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    int     rval = -1;
    do {
        uart_dev_t     *pHDev = (uart_dev_t*)pHandle;
        int             len = 0;
        int             buf_len = 0;
        int             rd_idx = pHDev->rd_idx;
        int             wr_idx = pHDev->wr_idx;

        buf_len = *pData_len;
        *pData_len = 0;

        if( !pHDev )   break;

        while( 1 )
        {
            if( rd_idx == wr_idx )      break;
            if( buf_len == len )        break;

            *pData++ = pHDev->pRx_buf[rd_idx];
            rd_idx = (rd_idx + 1) & (pHDev->rx_buf_len - 1);

            len++ ;
        }

        pHDev->rd_idx = rd_idx;

        *pData_len = len;
        rval = 0;
    } while(0);
    return rval;
}

static int
_win_uart_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
    do {
        uart_dev_t     *pHDev = (uart_dev_t*)pHandle;
        uint32_t        rd_idx = pHDev->rd_idx;
        uint32_t        wr_idx = pHDev->wr_idx;

        if( !pHDev )   break;

        if( state == COMM_STATE_GET_RX_EVENT )
        {
            // if empty, no rx_event
            rval = !(rd_idx == wr_idx);
        }
    } while(0);
    return rval;
}

static int
_win_uart_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
        uart_dev_t     *pHDev = (uart_dev_t*)pHandle;

        if( !pHDev )   break;

        pHDev->rd_idx = 0;
        pHDev->wr_idx = 0;

    } while(0);
    return rval;
}

static int
_win_uart_ctrl(
    comm_handle_t   pHandle,
    uint32_t        op_code,
    uint32_t        value,
    void            *pExtra)
{
    int             rval = 0;
    do {
        uart_dev_t     *pHDev = (uart_dev_t*)pHandle;

        if( !pHDev )   break;

        if( op_code == COMM_OPCODE_GET_DEV_TYPE )
        {
            comm_ctrl_argv_t    *pCtrl = (comm_ctrl_argv_t*)pExtra;

            if( !pCtrl )        break;

            pCtrl->argv[0] = pHDev->dev_type;
        }

    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_ops_t      g_comm_ops_uart_win =
{
    .dev_type      = COMM_DEV_TYPE_UART,
    .init          = _win_uart_init,
    .deinit        = _win_uart_deinit,
    .send_bytes    = _win_uart_send_bytes,
    .recv_bytes    = _win_uart_recv_bytes,
    .get_state     = _win_uart_get_state,
    .reset_buf     = _win_uart_reset_buf,
    .ctrl          = _win_uart_ctrl,
};
#else
comm_ops_t      g_comm_ops_uart_win = {0};
#endif