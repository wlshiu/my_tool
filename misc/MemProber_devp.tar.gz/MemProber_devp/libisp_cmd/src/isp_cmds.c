/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file cmds.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */


#include <string.h>
#include "log.h"
#include "isp.h"
#include "isp_cmds.h"
#include "sys_arch.h"

//=============================================================================
//                  Constant Definition
//=============================================================================
#define ISP_CMD_FLAG_VALUE          0

#define ISP_PING_INC_ID             (('V' << 24) | ('A' << 16) | ('N' << 8) | 'G')
#define ISP_PING_CHIP_ID            (('p' << 24) | ('h' << 16) | ('n' << 8) | 'x')
//=============================================================================
//                  Macro Definition
//=============================================================================
/**
 *  @brief Brief    SET_2BYTES_VALUE (little-endian )
 *
 *  @param [in] pCur    current pointer of buffer
 *  @param [in] value   the data
 *
 */
#define SET_2BYTES_VALUE(pCur, value)       do{ *pCur++ = (value) & 0xFF;        \
                                                *pCur++ = ((value) >> 8) & 0xFF; \
                                            }while(0)
#define GET_2BYTES_VALUE(pCur)              (((uint8_t*)(pCur))[1] << 8 | ((uint8_t*)(pCur))[0])

/**
 *  @brief Brief    SET_4BYTES_VALUE (little-endian )
 *
 *  @param [in] pCur    current pointer of buffer
 *  @param [in] value   the data
 *
 */
#define SET_4BYTES_VALUE(pCur, value)       do{ *pCur++ = (value) & 0xFF;        \
                                                *pCur++ = ((value) >> 8) & 0xFF;  \
                                                *pCur++ = ((value) >> 16) & 0xFF; \
                                                *pCur++ = ((value) >> 24) & 0xFF; \
                                            }while(0)

#define GET_4BYTES_VALUE(pCur)              (((uint8_t*)(pCur))[0] | ((uint8_t*)(pCur))[1] << 8 | \
                                             ((uint8_t*)(pCur))[2] << 16 |((uint8_t*)(pCur))[3] <<24)

#define CONVERT_TO_PKG_SIZE(len)            ((len) ? sizeof(isp_cmd_hdr_t) + ((len) << 2) + 1 : sizeof(isp_cmd_hdr_t))
//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================
#if 0
static ISP_ERR_t
isp_cmd_xxx(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = ; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        //-----------------------------
        // TODO: behavior
        msg("xxxxx -->\n");

        *pCur         = _isp_cmd_calc_checksum(pOut_buf + sizeof(isp_cmd_hdr_t), hdr.len << 2);
        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}


#endif // 0

static uint32_t
_isp_cmd_calc_checksum(
    uint8_t     *pData,
    int         len)
{
    uint32_t    sum = 0;
    for(int i = 0; i < len; ++i)
        sum += pData[i];

    return (sum & 0xFF);
}

static void
_isp_cmd_check_remote_status(uint8_t status)
{
    switch(status)
    {
        case ISP_ACK_OK:    break;

        case ISP_ACK_MISCHECKSUM:           msg_color(RED, "%s", "Checksum not match\n"); break;
        case ISP_ACK_TIMEOUT:               msg_color(RED, "%s", "Process timeout \n"); break;
        case ISP_ACK_OUT_BUF_LEN:           msg_color(RED, "%s", "Exceed buffer length\n"); break;
        case ISP_ACK_NOT_SUPPORT:           msg_color(RED, "%s", "Not support this request\n"); break;
        case ISP_ACK_VERSION_NOT_MATCH:     msg_color(RED, "%s", "Tool version not match\n"); break;
        case ISP_ACK_ADDR_NOT_ALIGNMENT:    msg_color(RED, "%s", "Address is not alignment\n"); break;
        case ISP_ACK_SYSTEM_BUSY:           msg_color(RED, "%s", "Remote system busy\n"); break;
        case ISP_ACK_UNKNOWN:
        default:
            msg_color(RED, "remote unknown fail (state:0x%02x)\n", status);
            break;
    }
    return;
}

static ISP_ERR_t
isp_cmd_report_DEFAUT(
    isp_argv_t  *pArgv,
    uint8_t     *pIn_buf,
    int         in_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};

        memcpy(&hdr, pIn_buf, sizeof(hdr));
        if( hdr.status != ISP_ACK_OK )
        {
            _isp_cmd_check_remote_status(hdr.status);
            break;
        }

        msg("<-- remote ok\n");

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_PING(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = 0;
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

        msg("ping remote -->\n");
    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_report_PING(
    isp_argv_t  *pArgv,
    uint8_t     *pIn_buf,
    int         in_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint32_t            uid_tag[2] = {0};

        memcpy(&hdr, pIn_buf, sizeof(hdr));
        if( hdr.status != ISP_ACK_OK )
        {
            _isp_cmd_check_remote_status(hdr.status);
            break;
        }

        memcpy((uint8_t*)&uid_tag, &pIn_buf[sizeof(hdr)], sizeof(uid_tag));
        if( uid_tag[0] != ISP_PING_INC_ID || uid_tag[1] != ISP_PING_CHIP_ID )
        {
            err("Get wrong TAG (Version are not match between ROM and this tool)\n");
            break;
        }

        msg("<-- ACK\n");

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_REBOOT(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint8_t             *pCur = 0;
        int                 cur_len = sizeof(isp_cmd_hdr_t);

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = 1; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        pCur = pOut_buf + cur_len;
        SET_4BYTES_VALUE(pCur, pArgv->reboot.remap_type);

        *pCur = _isp_cmd_calc_checksum(pOut_buf + sizeof(isp_cmd_hdr_t), hdr.len << 2);

        msg("reboot (remap= %d) -->\n", pArgv->reboot.remap_type);

        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_READ_4BYTES(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint8_t             *pCur = 0;
        int                 cur_len = sizeof(isp_cmd_hdr_t);
        uint32_t            read_len = 0;

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = 2; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        //-----------------------------
        pCur = pOut_buf + cur_len;
        SET_4BYTES_VALUE(pCur, pArgv->rd.address);

        read_len = (pArgv->rd.byte_len + 0x3) >> 2;
        SET_4BYTES_VALUE(pCur, read_len);

        msg("rd x%08X (%d bytes) -->\n", pArgv->rd.address, pArgv->rd.byte_len);

        *pCur         = _isp_cmd_calc_checksum(pOut_buf + sizeof(isp_cmd_hdr_t), hdr.len << 2);
        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_report_READ_4BYTES(
    isp_argv_t  *pArgv,
    uint8_t     *pIn_buf,
    int         in_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};

        memcpy(&hdr, pIn_buf, sizeof(hdr));
        if( hdr.status != ISP_ACK_OK )
        {
            _isp_cmd_check_remote_status(hdr.status);
            break;
        }

        msg("<-- read %d bytes \n", in_buf_len);

        switch( pArgv->rd.layout )
        {
            case ISP_DATA_LAYOUT_UINT32_LE:
                {
                    uint32_t    addr = pArgv->rd.address;
                    uint32_t    cnt = in_buf_len >> 2;
                    uint32_t    *pCur = (uint32_t*)(pIn_buf + sizeof(hdr));

                    msg("addr       0        4        8        C       \n");
                    msg("-------- | v------- v------- v------- v-------\n");
                    for(int i = 0; i < cnt; i++)
                    {
                        if( !(i & 0x3) )    msg("\n%08X |", addr);

                        msg(" %08X", pCur[i]);
                    }
                    msg("\n\n");
                }
                break;

            case ISP_DATA_LAYOUT_BYTE:
            default:
                {
                    uint32_t    addr = pArgv->rd.address;
                    uint8_t     *pCur = pIn_buf + sizeof(hdr);

                    msg("addr       0           4           8           C          \n");
                    msg("-------- | v- -- -- -- v- -- -- -- v- -- -- -- v- -- -- --\n");
                    for(int i = 0; i < in_buf_len; i++)
                    {
                        if( !(i & 0xF) )    msg("\n%08X |", addr);

                        msg(" %02X", pCur[i]);
                    }
                    msg("\n\n");
                }
                break;
        }

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_READ_CHECKSUM(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint8_t             *pCur = 0;
        int                 cur_len = sizeof(isp_cmd_hdr_t);
        uint32_t            read_len = 0;

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = 2; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        //-----------------------------
        pCur = pOut_buf + cur_len;
        SET_4BYTES_VALUE(pCur, pArgv->checksum.address);

        read_len = (pArgv->checksum.byte_len + 0x3) >> 2;
        SET_4BYTES_VALUE(pCur, read_len);

        msg("checksum x%08X (%d bytes) -->\n", pArgv->rd.address, read_len << 2);

        *pCur         = _isp_cmd_calc_checksum(pOut_buf + sizeof(isp_cmd_hdr_t), hdr.len << 2);
        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_report_READ_CHECKSUM(
    isp_argv_t  *pArgv,
    uint8_t     *pIn_buf,
    int         in_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint32_t            *pCur = 0;

        memcpy(&hdr, pIn_buf, sizeof(hdr));
        if( hdr.status != ISP_ACK_OK )
        {
            _isp_cmd_check_remote_status(hdr.status);
            break;
        }

        pCur = (uint32_t*)(pIn_buf + sizeof(hdr));

        msg("<-- checksum x%08X\n", *pCur);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_WRITE_4BYTES(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint8_t             *pCur = 0;
        int                 cur_len = sizeof(isp_cmd_hdr_t);

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = 2; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        //-----------------------------
        pCur = pOut_buf + cur_len;
        SET_4BYTES_VALUE(pCur, pArgv->wr.address);
        SET_4BYTES_VALUE(pCur, pArgv->wr.value);

        msg("wr x%08X x%08x-->\n", pArgv->wr.address, pArgv->wr.value);

        *pCur         = _isp_cmd_calc_checksum(pOut_buf + sizeof(isp_cmd_hdr_t), hdr.len << 2);
        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_ERASE(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint8_t             *pCur = 0;
        int                 cur_len = sizeof(isp_cmd_hdr_t);

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = (pArgv->cmd == ISP_CMD_ERASE_CHIP) ? 0 : 2; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        //-----------------------------
        pCur = pOut_buf + cur_len;
        if( pArgv->cmd == ISP_CMD_ERASE_CHIP )
        {
            SET_4BYTES_VALUE(pCur, pArgv->wr.value);
            msg("erase chip --> \n");
        }
        else
        {
            SET_4BYTES_VALUE(pCur, pArgv->erase.address);
            SET_4BYTES_VALUE(pCur, pArgv->erase.cnt);

            msg("erase x%08X %u %s --> \n", pArgv->erase.address, pArgv->erase.cnt,
                    (pArgv->cmd == ISP_CMD_ERASE_SECTOR) ? "sectors" :
                    (pArgv->cmd == ISP_CMD_ERASE_PAGE) ? "pages" : "blocks");
        }

        *pCur         = _isp_cmd_calc_checksum(pOut_buf + sizeof(isp_cmd_hdr_t), hdr.len << 2);
        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_GET_FLASH_ID(
    isp_argv_t  *pArgv,
    uint8_t     *pOut_buf,
    int         *pOut_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};

        hdr.cmd  = pArgv->cmd;
        hdr.flag = ISP_CMD_FLAG_VALUE;
        hdr.len  = 0; // the cardinal number is 4 bytes
        memcpy(pOut_buf, (uint8_t*)&hdr, sizeof(hdr));

        msg("get flash ID -->\n");

        *pOut_buf_len = CONVERT_TO_PKG_SIZE(hdr.len);

    } while(0);
    return rval;
}

static ISP_ERR_t
isp_cmd_report_GET_FLASH_ID(
    isp_argv_t  *pArgv,
    uint8_t     *pIn_buf,
    int         in_buf_len)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        isp_cmd_hdr_t       hdr = {0};
        uint32_t            flash_ID = 0;

        memcpy(&hdr, pIn_buf, sizeof(hdr));
        if( hdr.status != ISP_ACK_OK )
        {
            _isp_cmd_check_remote_status(hdr.status);
            break;
        }

        memcpy(&flash_ID, &pIn_buf[sizeof(hdr)], sizeof(flash_ID));

        msg("<-- flash ID x%08X\n", flash_ID);

    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
isp_cmd_attr_t      g_isp_cmd_list[] =
{
    { .cmd = ISP_CMD_PING,          .ack_num = 1,  .pf_cmd_pack = isp_cmd_PING,         .pf_cmd_report = isp_cmd_report_PING, },
    { .cmd = ISP_CMD_REBOOT,        .ack_num = 1,  .pf_cmd_pack = isp_cmd_REBOOT,       .pf_cmd_report = 0, },
    { .cmd = ISP_CMD_READ_4BYTES,   .ack_num = 1,  .pf_cmd_pack = isp_cmd_READ_4BYTES,  .pf_cmd_report = isp_cmd_report_READ_4BYTES, },
    { .cmd = ISP_CMD_READ_CHECKSUM, .ack_num = 1,  .pf_cmd_pack = isp_cmd_READ_CHECKSUM, .pf_cmd_report = isp_cmd_report_READ_CHECKSUM, },
    { .cmd = ISP_CMD_WRITE_4BYTES,  .ack_num = 1,  .pf_cmd_pack = isp_cmd_WRITE_4BYTES, .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_WRITE_DATA,    .ack_num = 2,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_GET_FLASH_ID,  .ack_num = 1,  .pf_cmd_pack = isp_cmd_GET_FLASH_ID, .pf_cmd_report = isp_cmd_report_GET_FLASH_ID, },
    { .cmd = ISP_CMD_PAGE_PROGRAM,  .ack_num = 1,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_VTEFC_INIT,    .ack_num = 2,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_ERASE_SECTOR,  .ack_num = 2,  .pf_cmd_pack = isp_cmd_ERASE,        .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_ERASE_PAGE,    .ack_num = 2,  .pf_cmd_pack = isp_cmd_ERASE,        .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_ERASE_BLOCK,   .ack_num = 2,  .pf_cmd_pack = isp_cmd_ERASE,        .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_ERASE_CHIP,    .ack_num = 2,  .pf_cmd_pack = isp_cmd_ERASE,        .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_QUAD_MODE,     .ack_num = 2,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_PROTECTION,    .ack_num = 2,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_CMD_GET_REMAP,     .ack_num = 1,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .cmd = ISP_COMBO_CMD_LOAD,    .ack_num = 1,  .pf_cmd_pack = 0,                    .pf_cmd_report = isp_cmd_report_DEFAUT, },
    { .pf_cmd_pack = (void*)-1, },
};

