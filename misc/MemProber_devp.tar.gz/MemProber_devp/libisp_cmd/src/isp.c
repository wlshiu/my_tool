/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file isp.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */


#include <string.h>
#include "comm_dev.h"
#include "isp.h"
#include "isp_cmds.h"
#include "log.h"
#include "sys_arch.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#define CONFIG_OUT_BUF_LEN              4096
#define CONFIG_IN_BUF_LEN               4096
#define CONFIG_RESP_TIMEOUT_SEC         300 // 30
//#define CONFIG_REMOTE_RUN_TIMEOUT_SEC   30
//=============================================================================
//                  Macro Definition
//=============================================================================
#define stringize(s)        #s
#define _toStr(a)           stringize(a)
//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================
//extern isp_cmd_attr_t       g_isp_cmd_list[];

static comm_handle_t        g_hComm = 0;
static uint32_t             g_out_buf[CONFIG_OUT_BUF_LEN >> 2] = {0};
static uint32_t             g_in_buf[CONFIG_IN_BUF_LEN >> 2] = {0};
//=============================================================================
//                  Private Function Definition
//=============================================================================
__unused static void
_isp_check_host_err(int isp_err_code)
{
    switch( isp_err_code )
    {
        case ISP_ERR_SUCCESS:   break;

        case ISP_ERR_INVALID_DEVICE:    msg_color(RED, "%s", _toStr(ISP_ERR_INVALID_DEVICE) "\n"); break;
        case ISP_ERR_ARGUMENT:          msg_color(RED, "%s", _toStr(ISP_ERR_ARGUMENT) "\n"); break;
        case ISP_ERR_TIMEOUT:           msg_color(RED, "%s", _toStr(ISP_ERR_TIMEOUT) "\n"); break;
        case ISP_ERR_UNKNOWN_CMD:       msg_color(RED, "%s", _toStr(ISP_ERR_UNKNOWN_CMD) "\n"); break;
        case ISP_ERR_UNKNOWN_IMG:       msg_color(RED, "%s", _toStr(ISP_ERR_UNKNOWN_IMG) "\n"); break;
        case ISP_ERR_NOT_SUPPORT:       msg_color(RED, "%s", _toStr(ISP_ERR_NOT_SUPPORT) "\n"); break;
        case ISP_ERR_IO_READ:           msg_color(RED, "%s", _toStr(ISP_ERR_IO_READ) "\n"); break;
        case ISP_ERR_IO_WRITE:          msg_color(RED, "%s", _toStr(ISP_ERR_IO_WRITE) "\n"); break;
        case ISP_ERR_IO_GENERIC:        msg_color(RED, "%s", _toStr(ISP_ERR_IO_GENERIC) "\n"); break;
        case ISP_ERR_IO_SIZE:           msg_color(RED, "%s", _toStr(ISP_ERR_IO_SIZE) "\n"); break;
        case ISP_ERR_NO_ACK:            msg_color(RED, "%s", _toStr(ISP_ERR_NO_ACK) "\n"); break;
        case ISP_ERR_CHECKSUM_FAIL:     msg_color(RED, "%s", _toStr(ISP_ERR_CHECKSUM_FAIL) "\n"); break;
        case ISP_ERR_FORMAT:            msg_color(RED, "%s", _toStr(ISP_ERR_FORMAT) "\n"); break;
        case ISP_ERR_ALLOC:             msg_color(RED, "%s", _toStr(ISP_ERR_ALLOC) "\n"); break;
        case ISP_ERR_PROTOCOL:          msg_color(RED, "%s", _toStr(ISP_ERR_PROTOCOL) "\n"); break;
        case ISP_ERR_FAILED:
        default:
            msg_color(RED, "%s", _toStr(ISP_ERR_FAILED) "\n"); break;
            break;
    }
    return;
}

static ISP_ERR_t
_isp_wait_response(
    uint8_t     *pIn_buf,
    int         *pIn_buf_len,
    uint32_t    timeout_sec)
{
    ISP_ERR_t   rval = ISP_ERR_TIMEOUT;
    do {
        uint8_t     *pIn_buf_cur = pIn_buf;
        int         input_len = 0;
        int         in_buf_len = *pIn_buf_len;
        int         buf_remain = *pIn_buf_len;
        void        *start_time = sys_get_curr_time();
        uint32_t    data_size = 0;

        *pIn_buf_len = 0;

        while( sys_get_duration(start_time) < timeout_sec * 1000 )
        {
            if( !comm_dev_get_state(g_hComm, COMM_STATE_GET_RX_EVENT) )
            {
                sys_usleep(1000);
                continue;
            }

            // partially receive data
            comm_dev_recv_bytes(g_hComm, pIn_buf_cur, &buf_remain);
            input_len += buf_remain;
            pIn_buf_cur = &pIn_buf[input_len];
            buf_remain  = in_buf_len - input_len;

            if( input_len < 4 )
                continue;

            if( pIn_buf[0] != ISP_CMD_ACK )
            {
                err("%s", "Receive wrong ACK data\n");
                rval = ISP_ERR_PROTOCOL;
                break;
            }

            data_size = ((uint32_t)pIn_buf[3] << 8) | ((uint32_t)pIn_buf[2]);
            data_size <<= 2; // the cardinal number is 4 bytes
            if( data_size == 0 || input_len >= (data_size + 1) ) // checksum occupies 1 byte
            {
                rval = ISP_ERR_SUCCESS;
                break;
            }
        }

        if( rval != ISP_ERR_SUCCESS )    break;

        // verify checksum of received data
        if( data_size )
        {
            uint32_t    sum = 0;
            for(int i = 0; i < data_size; i++)
                sum += pIn_buf[i + 4];

            if( (sum & 0xFF) != pIn_buf[data_size + 4] )
            {
                err("the checksum of received data is fail (x%02x/x%02x)\n", (sum & 0xFF), pIn_buf[data_size + 4]);
                rval = ISP_ERR_CHECKSUM_FAIL;
                break;
            }
        }

        *pIn_buf_len = data_size;
    } while(0);
    return rval;
}

static ISP_ERR_t
_isp_wait_welcome(
    uint8_t     *pIn_buf,
    int         *pIn_buf_len,
    uint32_t    timeout_sec)
{
    ISP_ERR_t   rval = ISP_ERR_TIMEOUT;
    do {
        uint8_t     *pIn_buf_cur = pIn_buf;
        int         input_len = 0;
        int         in_buf_len = *pIn_buf_len;
        int         buf_remain = *pIn_buf_len;
        void        *start_time = sys_get_curr_time();

        *pIn_buf_len = 0;

        while( sys_get_duration(start_time) < timeout_sec * 1000 )
        {
            if( !comm_dev_get_state(g_hComm, COMM_STATE_GET_RX_EVENT) )
            {
                sys_usleep(1000);
                continue;
            }

            // partially receive data
            comm_dev_recv_bytes(g_hComm, pIn_buf_cur, &buf_remain);
            input_len += buf_remain;
            pIn_buf_cur = &pIn_buf[input_len];
            buf_remain  = in_buf_len - input_len;

            if( input_len < 30 )
                continue;

            for(int i = 0; i < input_len; i++)
                msg("%c", pIn_buf[i]);
            msg("\n\n");

            rval = ISP_ERR_SUCCESS;
            break;
        }

        if( rval != ISP_ERR_SUCCESS )    break;

    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
ISP_ERR_t
isp_init(
    isp_setting_t   *pSetting)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        // initial communication device
        comm_cfg_t      cfg = {0};

        cfg.act_dev_type = pSetting->dev_type;
        switch( cfg.act_dev_type )
        {
            case COMM_DEV_TYPE_UART:
                cfg.uart.baud_rate  = pSetting->dev_attr.uart.baud_rate;
                cfg.uart.port       = pSetting->dev_attr.uart.port;
                break;

            case COMM_DEV_TYPE_SPI:
                cfg.spi.speed = pSetting->dev_attr.spi.speed;
                break;

            default:
                err("unknown communication interface %d\n", pSetting->dev_type);
                rval = ISP_ERR_INVALID_DEVICE;
                break;
        }

        if( rval != ISP_ERR_SUCCESS )  break;

        g_hComm = comm_dev_init(&cfg, pSetting->cb_set_user_ops);
        if( !g_hComm )
        {
            err("%s", "communication device initial fail \n");
            rval = ISP_ERR_FAILED;
            break;
        }
    } while(0);

    if( rval != ISP_ERR_SUCCESS )
    {
        _isp_check_host_err(rval);
    }
    return rval;
}

ISP_ERR_t
isp_process(
    isp_argv_t      *pArgv,
    cb_response_t   cb_response,
    void            *pTunnel_info)
{
    ISP_ERR_t     rval = ISP_ERR_SUCCESS;
    do {
        int                 out_len = sizeof(g_out_buf);
        int                 in_len = 0;
        isp_cmd_attr_t      *pIsp_cmd_cur = g_isp_cmd_list;

        memset(g_out_buf, 0x0, sizeof(g_out_buf));
        memset(g_in_buf, 0x0, sizeof(g_in_buf));

        while( pIsp_cmd_cur->pf_cmd_pack != (void*)-1 )
        {
            if( pIsp_cmd_cur->cmd == pArgv->cmd )
            {
                // generate cmd message
                rval = pIsp_cmd_cur->pf_cmd_pack(pArgv, (uint8_t*)g_out_buf, &out_len);
                break;
            }
            pIsp_cmd_cur++;
        }

        if( rval )
        {
            err("isp-cmd packs fail (err= %d)\n", rval);
            break;
        }

        // send command with communication device
        rval = comm_dev_send_bytes(g_hComm, (uint8_t*)g_out_buf, out_len);
        if( rval )
        {
            err("send command fail (err= %d)\n", rval);
            rval = ISP_ERR_IO_WRITE;
            break;
        }

        #if defined(CONFIG_SIM_MODE)
        comm_dev_reset_buf(g_hComm, 0, 0);
        #endif

        // wait response from remote
        if( pIsp_cmd_cur->cmd == ISP_CMD_REBOOT )
        {
            in_len = sizeof(g_in_buf);
            msg("Wait remote booting...\n");
            rval = _isp_wait_welcome((uint8_t*)g_in_buf, &in_len, 10);//CONFIG_RESP_TIMEOUT_SEC);
            break;
        }

        for(int i = 0; i < pIsp_cmd_cur->ack_num; i++)
        {
            in_len = sizeof(g_in_buf);
            rval = _isp_wait_response((uint8_t*)g_in_buf, &in_len, CONFIG_RESP_TIMEOUT_SEC);
            if( rval < 0 )
            {
                err("remote response fail %d\n", rval);
                break;
            }
        }

        if( rval < 0 )  break;

        // show result
        if( pIsp_cmd_cur->pf_cmd_report )
        {
            pIsp_cmd_cur->pf_cmd_report(pArgv, (uint8_t*)g_in_buf, in_len);
        }

        // callback received data to application layer
        if( cb_response )
            rval = cb_response(pArgv, (uint8_t*)g_in_buf, in_len, pTunnel_info);

    } while(0);

    if( rval != ISP_ERR_SUCCESS )
    {
        _isp_check_host_err(rval);
    }
    return rval;
}

ISP_ERR_t
isp_deinit(void)
{
    ISP_ERR_t     rval = 0;
    do {
        // terminate communication device
        comm_dev_deinit(g_hComm);
        g_hComm = 0;
    } while(0);
    return rval;
}




