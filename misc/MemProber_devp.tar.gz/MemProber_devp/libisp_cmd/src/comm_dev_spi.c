/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file comm_dev.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */


#include "comm_dev.h"

//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================
static comm_handle_t
_spi_init(comm_cfg_t *pCfg)
{
    do {
    } while(0);

	return (comm_handle_t)0;
}

static int
_spi_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    int     rval = 0;
    do {
    } while(0);
    return rval;
}

static int
_spi_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    int     rval = 0;
    do {

    } while(0);
    return rval;
}

static int
_spi_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
    return rval;
}

static int
_spi_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_ops_t      g_comm_ops_spi =
{
    .dev_type      = COMM_DEV_TYPE_SPI,
    .init          = _spi_init,
    .send_bytes    = _spi_send_bytes,
    .recv_bytes    = _spi_recv_bytes,
    .get_state     = _spi_get_state,
    .reset_buf     = _spi_reset_buf,
};




