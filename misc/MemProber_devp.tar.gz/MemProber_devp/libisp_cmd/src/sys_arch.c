/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file sys_arch.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/18
 * @license
 * @description
 */


#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "sys_arch.h"

//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================
static sys_port_t       g_sys_port = {0};
//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
int
sys_register_ops(
    sys_port_t  *pSys_port)
{
    memcpy(&g_sys_port, pSys_port, sizeof(g_sys_port));
    return 0;
}

void*
sys_get_curr_time(void)
{
    void    *rval = 0;
    if( g_sys_port.pf_get_cur_time )
        rval = g_sys_port.pf_get_cur_time();
    return rval;
}

uint32_t
sys_get_duration(void *start)
{
    uint32_t    rval = 0;
    if( g_sys_port.pf_get_duration )
        rval = g_sys_port.pf_get_duration(start);
    return rval;
}

void
sys_usleep(uint32_t usec)
{
    if( g_sys_port.pf_usleep )
        g_sys_port.pf_usleep(usec);
    return;
}

int
sys_log(char *format, ...)
{
    int     rval = -1;
    if( g_sys_port.pf_log )
    {
        va_list     args;
        va_start(args, format);
        g_sys_port.pf_log(format, args);
        va_end(args);
    }

    return rval;
}
