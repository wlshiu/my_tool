/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file comm_dev.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "log.h"
#include "comm_dev.h"

//=============================================================================
//                  Constant Definition
//=============================================================================
#define CONFIG_USE_STATIC_MEM       1

#define CONFIG_MAX_DEVICE_NUM       2
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct comm_dev
{
    comm_handle_t   hComm;
    comm_ops_t      *pComm_ops;

} comm_dev_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
extern comm_ops_t      g_comm_ops_uart;
extern comm_ops_t      g_comm_ops_spi;


static comm_ops_t*     g_pComm_ops_list[] =
{
    &g_comm_ops_uart,
    &g_comm_ops_spi,
    0
};
//=============================================================================
//                  Private Function Definition
//=============================================================================
static comm_dev_t*
_get_dev_handle(void)
{
    static comm_dev_t   g_dev[CONFIG_MAX_DEVICE_NUM] ={{.pComm_ops = 0,}};

    comm_dev_t      *pDev = 0;
    for(int i = 0; i < CONFIG_MAX_DEVICE_NUM; i++)
    {
        if( !g_dev[i].pComm_ops )
        {
            pDev = &g_dev[i];
            break;
        }
    }
    return pDev;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_handle_t
comm_dev_init(
    comm_cfg_t          *pCfg,
    cb_set_user_ops_t   cb_set_user_ops)
{
    comm_err_t  rval = COMM_ERR_OK;
    comm_dev_t  *pDev = 0;

    assert(pCfg);

    do {
    #if (CONFIG_USE_STATIC_MEM)
        if( !(pDev = _get_dev_handle()) )
        {
            err("%s", "create device fail\n");
            rval = COMM_ERR_ALLOCATE_FAIL;
            break;
        }
    #else
        if( !(pDev = malloc(sizeof(comm_dev_t))) )
        {
            err("%s", "create device fail\n");
            rval = COMM_ERR_ALLOCATE_FAIL;
            break;
        }
    #endif // 1

        memset(pDev, 0x0, sizeof(comm_dev_t));

        // search the active comm_ops
        if( cb_set_user_ops )
            pDev->pComm_ops = cb_set_user_ops(pCfg);
        else
        {
            int         i = 0;

            while( g_pComm_ops_list[i] )
            {
                if( g_pComm_ops_list[i]->dev_type == pCfg->act_dev_type )
                {
                    pDev->pComm_ops = g_pComm_ops_list[i];
                    break;
                }

                i++;
            }
        }

        if( !pDev->pComm_ops )
        {
            rval = COMM_ERR_INVALID_PARAM;
            break;
        }

        // call init method
        if( pDev->pComm_ops->init )
        {
            pDev->hComm = pDev->pComm_ops->init(pCfg);
            if( !pDev->hComm )
            {
                err("%s", "device init fail \n");
                rval = COMM_ERR_INVALID_PARAM;
                break;
            }
        }
    } while(0);

    if( rval )
    {
        comm_dev_deinit((comm_handle_t)pDev);
        pDev = 0;
    }

    return (comm_handle_t*)pDev;
}

comm_err_t
comm_dev_deinit(
    comm_handle_t   hComm)
{
    int     rval = 0;
    do {
        comm_dev_t  *pDev = (comm_dev_t*)hComm;

        if( !hComm )    break;

        if( pDev->pComm_ops && pDev->pComm_ops->deinit )
            pDev->pComm_ops->deinit(pDev->hComm);

    #if !(CONFIG_USE_STATIC_MEM)
        free(pDev);
    #endif

    } while(0);

    return rval;
}

comm_err_t
comm_dev_send_bytes(
    comm_handle_t   hComm,
    uint8_t         *pData,
    int             len)
{
    int     rval = 0;
    do {
        comm_dev_t  *pDev = (comm_dev_t*)hComm;

        if( !hComm || !pData || len <= 0 )
        {
            err("invalid parameters: hComm= %p, pData= %p, len= %d\n",
                hComm, pData, len);
            rval = COMM_ERR_INVALID_PARAM;
            break;
        }

        if( pDev->pComm_ops && pDev->pComm_ops->send_bytes )
            rval = pDev->pComm_ops->send_bytes(pDev->hComm, pData, len);

    } while(0);
    return rval;
}

comm_err_t
comm_dev_recv_bytes(
    comm_handle_t   hComm,
    uint8_t         *pData,
    int             *pLen)
{
    int     rval = 0;
    do {
        comm_dev_t  *pDev = (comm_dev_t*)hComm;

        if( !hComm || !pData || !pLen )
        {
            err("invalid parameters: hComm= %p, pData= %p, pLen= %p\n",
                hComm, pData, pLen);
            rval = COMM_ERR_INVALID_PARAM;
            break;
        }

        if( *pLen == 0 )
        {
            err("%s", "buffer length can't be 0\n");
            rval = COMM_ERR_INVALID_PARAM;
            break;
        }

        if( pDev->pComm_ops && pDev->pComm_ops->recv_bytes )
            rval = pDev->pComm_ops->recv_bytes(pDev->hComm, pData, pLen);

    } while(0);
    return rval;
}

comm_err_t
comm_dev_reset_buf(
    comm_handle_t   hComm,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int     rval = 0;
    do {
        comm_dev_t  *pDev = (comm_dev_t*)hComm;

        if( !hComm )
        {
            err("invalid parameters: hComm= %p\n", hComm);
            rval = COMM_ERR_INVALID_PARAM;
            break;
        }

        if( pDev->pComm_ops && pDev->pComm_ops->reset_buf )
            rval = pDev->pComm_ops->reset_buf(pDev->hComm, pBuf, buf_len);

    } while(0);
    return rval;
}

int
comm_dev_get_state(
    comm_handle_t   hComm,
    comm_state_t    state)
{
    int     rval = 0;
    do {
        comm_dev_t  *pDev = (comm_dev_t*)hComm;

        if( !hComm )
        {
            err("invalid parameters: hComm= %p\n", hComm);
            break;
        }

        if( pDev->pComm_ops && pDev->pComm_ops->get_state )
            rval = pDev->pComm_ops->get_state(pDev->hComm, state);

    } while(0);
    return rval;
}





