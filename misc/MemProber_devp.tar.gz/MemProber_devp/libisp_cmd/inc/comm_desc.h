/*
 * Copyright (c) 2019, Vango Technologies, Inc. - http://www.vangotech.com/tw/
 * All rights reserved.
 *
 */
/** @file comm_desc.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/03/11
 * @license
 * @description
 */


#ifndef __comm_desc_H_w68da991_l0ed_hf23_s831_u2fb1898c82a__
#define __comm_desc_H_w68da991_l0ed_hf23_s831_u2fb1898c82a__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
//=============================================================================
//                  Constant Definition
//=============================================================================
#define COMM_MSG_HEADER_SIZE           4 // bytes

typedef enum comm_dev_type
{
    COMM_DEV_TYPE_UART  = 0,
    COMM_DEV_TYPE_SPI,
    COMM_DEV_TYPE_TOTAL,
} comm_dev_type_t;

typedef enum comm_state
{
    COMM_STATE_UNKNOWN      = 0,
    COMM_STATE_GET_RX_EVENT,

} comm_state_t;
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef void*   comm_handle_t;

typedef struct comm_hdr
{
    uint8_t     cmd;
    union {
        uint8_t     flag;
        uint8_t     status;
    };

    uint16_t    length;

} comm_hdr_t;

typedef struct comm_cfg
{
    comm_dev_type_t     act_dev_type;

    union {
        struct {
            uint32_t    port;
            uint32_t    baud_rate;
        } uart;

        struct {
            uint32_t    speed;
        } spi;

        struct {
            void    *pTunnel_info;
        } def;
    };

    uint8_t     *pBuf;
    uint32_t    buf_len;

} comm_cfg_t;

typedef struct comm_ops
{
    comm_dev_type_t     dev_type;

    comm_handle_t       (*init)(comm_cfg_t *pCfg);
    int                 (*deinit)(comm_handle_t pHandle);

    /**
     *  @brief
     *
     *  @param [in] pHandle     communication handle
     *  @param [in] state       state type, enum comm_state
     *  @return
     *      0    : nothing
     *      other: the state is triggered
     */
    int     (*get_state)(comm_handle_t pHandle, comm_state_t state);

    /**
     *  @brief  send_bytes
     *
     *  @param [in] pHandle     communication handle
     *  @param [in] pData       data buffer pointer
     *  @param [in] data_len    length of data
     *  @return
     *      0: ok, other: fail
     */
    int     (*send_bytes)(comm_handle_t pHandle, uint8_t *pData, int data_len);

    /**
     *  @brief  recv_bytes
     *
     *  @param [in] pHandle     communication handle
     *  @param [in] pData       data buffer pointer
     *  @param [in] pData_len   length of data
     *  @return
     *      0: ok, other: fail
     */
    int     (*recv_bytes)(comm_handle_t pHandle, uint8_t *pData, int *pData_len);

    /**
     *  @brief  reset_buf
     *              This api will reset read/write index.
     *              It also support to assign new buffer adderss and new buffer length
     *
     *  @param [in] pBuf        new buffer address
     *  @param [in] buf_len     new buffer length
     *  @return
     *      0: ok, other: fail
     */
    int     (*reset_buf)(comm_handle_t pHandle, uint8_t *pBuf, uint32_t buf_len);
} comm_ops_t;

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================

#ifdef __cplusplus
}
#endif

#endif


