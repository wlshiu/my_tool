/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file comm_dev.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */


#ifndef __comm_dev_H_43458700_497f_4bce_aada_d38a5e9de292__
#define __comm_dev_H_43458700_497f_4bce_aada_d38a5e9de292__

#ifdef __cplusplus
extern "C" {
#endif

#include "comm_desc.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
typedef enum comm_err
{
    COMM_ERR_OK             = 0,
    COMM_ERR_ALLOCATE_FAIL,
    COMM_ERR_INVALID_PARAM,
    COMM_ERR_UNKNOWN,

} comm_err_t;

typedef comm_ops_t* (*cb_set_user_ops_t)(comm_cfg_t *pCfg);
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_handle_t
comm_dev_init(
    comm_cfg_t          *pCfg,
    cb_set_user_ops_t   cb_set_user_ops);


comm_err_t
comm_dev_deinit(
    comm_handle_t   hComm);


comm_err_t
comm_dev_send_bytes(
    comm_handle_t   hComm,
    uint8_t         *pData,
    int             len);


comm_err_t
comm_dev_recv_bytes(
    comm_handle_t   hComm,
    uint8_t         *pData,
    int             *pLen);


comm_err_t
comm_dev_reset_buf(
    comm_handle_t   hComm,
    uint8_t         *pBuf,
    uint32_t        buf_len);


int
comm_dev_get_state(
    comm_handle_t   hComm,
    comm_state_t    state);


#ifdef __cplusplus
}
#endif

#endif


