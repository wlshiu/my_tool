/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file cmds.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */


#ifndef __cmds_H_6599d1ef_aa97_45d3_acca_e4a89567a23b__
#define __cmds_H_6599d1ef_aa97_45d3_acca_e4a89567a23b__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
#pragma pack(1)
typedef struct isp_cmd_hdr
{
    uint8_t         cmd;
    union {
        uint8_t         flag;
        uint8_t         status;
    };

    uint16_t        len;
} isp_cmd_hdr_t;

typedef struct isp_cmd_rst_READ_4BYTES
{
    isp_cmd_hdr_t   hdr;
    uint32_t        pData[];

} isp_cmd_rst_READ_4BYTES_t;

typedef struct isp_cmd_rst_READ_CHECKSUM
{
    isp_cmd_hdr_t   hdr;
    uint32_t        checksum;

} isp_cmd_rst_READ_CHECKSUM_t;

typedef struct isp_cmd_rst_GET_FLASH_ID
{
    isp_cmd_hdr_t   hdr;
    uint32_t        flash_id;

} isp_cmd_rst_GET_FLASH_ID_t;

typedef struct isp_cmd_rst_QUAD_MODE
{
    isp_cmd_hdr_t   hdr;
    uint32_t        is_enable;

} isp_cmd_rst_QUAD_MODE_t;

typedef struct isp_cmd_rst_PROTECTION
{
    isp_cmd_hdr_t   hdr;
    uint32_t        is_enable;

} isp_cmd_rst_PROTECTION_t;

typedef struct isp_cmd_rst_GET_REMAP
{
    isp_cmd_hdr_t   hdr;
    uint32_t        remap_type;

} isp_cmd_rst_GET_REMAP_t;


#pragma pack()
//=============================================================================
//                  Global Data Definition
//=============================================================================
extern isp_cmd_attr_t      g_isp_cmd_list[];
//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================

#ifdef __cplusplus
}
#endif

#endif


