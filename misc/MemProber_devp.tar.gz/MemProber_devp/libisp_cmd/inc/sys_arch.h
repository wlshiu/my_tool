/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file sys_arch.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/18
 * @license
 * @description
 */


#ifndef __sys_arch_H_af63360f_b9eb_479a_8caf_02e6bfc07cd2__
#define __sys_arch_H_af63360f_b9eb_479a_8caf_02e6bfc07cd2__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================
#ifndef __unused
    #define __unused        __attribute__ ((unused))
#endif

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct sys_port
{
    void*       (*pf_get_cur_time)();
    uint32_t    (*pf_get_duration)(void *start);
    void        (*pf_usleep)(uint32_t usec);
    int         (*pf_log)(char *format, ...);
} sys_port_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
int
sys_register_ops(
    sys_port_t  *pSys_port);


/**
 *  @brief Get current time
 *
 *  @return A handler of time
 *
 */
void*
sys_get_curr_time(void);


/**
 *  @brief Get time duration
 *
 *  @param [in] start   A handler of time
 *  @return Return      duration with msec
 *
 */
uint32_t
sys_get_duration(void *start);


void
sys_usleep(uint32_t usec);


int
sys_log(char *format, ...);


#ifdef __cplusplus
}
#endif

#endif


