/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file isp.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */


#ifndef __isp_H_e5c1c6ce_957f_4b35_b852_d08d963136fb__
#define __isp_H_e5c1c6ce_957f_4b35_b852_d08d963136fb__

#ifdef __cplusplus
extern "C" {
#endif


#include <stdint.h>
#include "comm_dev.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
typedef enum ISP_CMD
{
    /**
     *  hint: 0x00 && 0xff is not suitable for command encoding since the default
     *  state on the data bus is either 0x00 or 0xff and could be a garbage data
     *  if the master and slave state-switch is out of sync.
     */
    ISP_CMD_PING          = 0x0F,
    ISP_CMD_ACK           = 0xF0,
    ISP_CMD_REBOOT        = 0xF5,

    // read
    ISP_CMD_READ_4BYTES   = 0x11,
    ISP_CMD_READ_CHECKSUM = 0x12,

    // write
    ISP_CMD_WRITE_DMA     = 0x51,
    ISP_CMD_WRITE_4BYTES  = 0x52,
    ISP_CMD_WRITE_DATA    = 0x53,

    // flash control
    ISP_CMD_GET_FLASH_ID  = 0x90,
    ISP_CMD_PAGE_PROGRAM  = 0x91,
    ISP_CMD_VTEFC_INIT    = 0x92,
    ISP_CMD_ERASE_SECTOR  = 0x93,
    ISP_CMD_ERASE_PAGE    = 0x94,
    ISP_CMD_ERASE_BLOCK   = 0x95,
    ISP_CMD_ERASE_CHIP    = 0x96,
    ISP_CMD_QUAD_MODE     = 0x97,
    ISP_CMD_PROTECTION    = 0x98,

    // misc
    ISP_CMD_GET_REMAP     = 0xC1,
    ISP_CMD_SETUP         = 0xC2,
    ISP_CMD_BREAK         = 0xCC,

    // FIXME: the old version ghost
    ISP_CMD_PING_OLD          = 0x00,
    ISP_CMD_ACK_OLD           = 0xFF,
    ISP_CMD_WORD_READ_OLD     = 0x01, // common sense: "a word == 2 bytes", but here "a word == 4 bytes" (WTF !!!)
    ISP_CMD_WORD_WRITE_OLD    = 0x02, // common sense: "a word == 2 bytes", but here "a word == 4 bytes" (WTF !!!)
    ISP_CMD_READ_CHECKSUM_OLD = 0x03, // return the checksum of all data
    ISP_CMD_PAGE_PROGRAM_OLD  = 0x05,
    ISP_CMD_VTEFC_INIT_OLD    = 0x06,

    /**
     *  combo commands
     *      it integrates behavior of multi-commands
     */
    ISP_COMBO_CMD_LOAD        = 0xD0,
} ISP_CMD_t;

typedef enum ISP_ACK_STATUS
{
    ISP_ACK_OK                  = 0x00,
    ISP_ACK_UNKNOWN             = 0xE0,  // unknown command
    ISP_ACK_MISCHECKSUM         = 0xE1,  // checksum mis-match
    ISP_ACK_TIMEOUT             = 0xE2,
    ISP_ACK_OUT_BUF_LEN         = 0xE3,
    ISP_ACK_NOT_SUPPORT         = 0xE4,
    ISP_ACK_VERSION_NOT_MATCH   = 0xE5,
    ISP_ACK_ADDR_NOT_ALIGNMENT  = 0xE6,
    ISP_ACK_SYSTEM_BUSY         = 0xE7,

} ISP_ACK_STATUS_t;

typedef enum ISP_ERR
{
    ISP_ERR_SUCCESS           = 0,
    ISP_ERR_FAILED            = -1,
    ISP_ERR_INVALID_DEVICE    = -2,
    ISP_ERR_ARGUMENT          = -3,
    ISP_ERR_TIMEOUT           = -4,
    ISP_ERR_UNKNOWN_CMD       = -5,
    ISP_ERR_UNKNOWN_IMG       = -6,
    ISP_ERR_NOT_SUPPORT       = -7,
    ISP_ERR_IO_READ           = -10,
    ISP_ERR_IO_WRITE          = -11,
    ISP_ERR_IO_GENERIC        = -12,
    ISP_ERR_IO_SIZE           = -13,
    ISP_ERR_NO_ACK            = -20,
    ISP_ERR_CHECKSUM_FAIL     = -21,
    ISP_ERR_FORMAT            = -22,
    ISP_ERR_ALLOC             = -30,
    ISP_ERR_PROTOCOL          = -90,
} ISP_ERR_t;

typedef enum ISP_DATA_LAYOUT
{
    ISP_DATA_LAYOUT_BYTE        = 0,
    ISP_DATA_LAYOUT_UINT32_LE   = 1,
} ISP_DATA_LAYOUT_t;
//=============================================================================
//                  Macro Definition
//=============================================================================
struct isp_argv;
typedef ISP_ERR_t (*cb_response_t)(struct isp_argv *pArgv,
                                  uint8_t   *pBuf_rx,
                                  int       len,
                                  void      *pTunnel_info);
//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct isp_setting
{
    comm_dev_type_t     dev_type;
    cb_set_user_ops_t   cb_set_user_ops;

    union{
        struct {
            uint32_t    baud_rate;
            uint32_t    port;
        } uart;

        struct {
            uint32_t    speed;
        } spi;
    } dev_attr;

} isp_setting_t;

typedef struct def_argv
{
    union {
        char        *pArgv;
        uint32_t    integer_num;
        float       float_num;
    };
} def_argv_t;

typedef struct isp_argv
{
    ISP_CMD_t       cmd;

    union {
        struct {
            uint32_t    address;
            uint32_t    byte_len;
            uint32_t    layout;
        } rd;

        struct {
            uint32_t    address;
            uint32_t    byte_len;
        } checksum;

        struct {
            uint32_t    address;
            uint32_t    value;
        } wr;

        struct {
            uint32_t    remap_type;
        } reboot;

        struct {
            uint32_t    address;
            uint32_t    cnt;
        } erase;

        struct {
            uint32_t    address;
            uint32_t    data_len;
            uint8_t     *pData;
        } pp; // page program

        struct {
            uint32_t    address;
            uint32_t    send_mode;
            uint32_t    verify_mode;
            char        *pImg_path;
        } load;

        struct {
            def_argv_t  argv[6];
        } def;
    };
} isp_argv_t;


typedef struct isp_cmd_attr
{
    ISP_CMD_t     cmd;

    /**
     *  amount of ACK packages
     */
    uint32_t        ack_num;

    ISP_ERR_t     (*pf_cmd_pack)(isp_argv_t *pArgv, uint8_t *pOut_buf, int *pOut_buf_len);
    ISP_ERR_t     (*pf_cmd_report)(isp_argv_t *pArgv, uint8_t *pIn_buf, int in_buf_len);
} isp_cmd_attr_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
ISP_ERR_t
isp_init(
    isp_setting_t   *pSetting);


ISP_ERR_t
isp_process(
    isp_argv_t      *pArgv,
    cb_response_t   cb_response,
    void            *pTunnel_info);


ISP_ERR_t
isp_deinit(void);


#ifdef __cplusplus
}
#endif

#endif


