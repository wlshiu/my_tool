/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file global.h
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/18
 * @license
 * @description
 */


#ifndef __global_H_13232305_ca49_42fa_a5f5_f0ee83716320__
#define __global_H_13232305_ca49_42fa_a5f5_f0ee83716320__

#ifdef __cplusplus
extern "C" {
#endif

#include "comm_dev.h"
#include "isp.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#define UID_PRIV_BASE           0x50000000
typedef enum uid_priv
{
    UID_PRIV_OPN_HELP       = (UID_PRIV_BASE | 0x0),
    UID_PRIV_CMD_IGNORE     = (UID_PRIV_BASE | 0x1),
    UID_PRIV_OPN_COMMIF     = (UID_PRIV_BASE | 0x2),
    UID_PRIV_CMD_LOAD       = (UID_PRIV_BASE | 0x3),
    UID_PRIV_CMD_ERASE      = (UID_PRIV_BASE | 0x4),

} uid_priv_t;
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct prog_argv
{
    uid_priv_t          uid;
    comm_dev_type_t     comm_if;
    isp_argv_t          isp_argv;
} prog_argv_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
//extern prog_argv_t      g_prog_argv;
//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================

#ifdef __cplusplus
}
#endif

#endif


