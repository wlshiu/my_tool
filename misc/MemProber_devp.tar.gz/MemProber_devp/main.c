
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include "log.h"
#include "global.h"
#include "cmd_util.h"
#include "isp.h"
#include "isp_cmds.h"
#include "sys_arch.h"


//=============================================================================
//                  Constant Definition
//=============================================================================
#ifndef __unused
    #define __unused        __attribute__ ((unused))
#endif

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================
#if defined(CONFIG_SIM_MODE)
    #include <windows.h>
    #include "pthread.h"

    static int      g_is_running_rom = 1;
#endif // #if defined(CONFIG_SIM_MODE)

static prog_argv_t      g_prog_argv = {0};
//=============================================================================
//                  Private Function Definition
//=============================================================================
static __unused void
_usage(void)
{
    fprintf(stderr, "Usage: MemProber [options] [commands] ...\n\n");
    fflush(stderr);
    cmd_util_dump_description();
    fprintf(stderr, "\n\n");
    exit(-1);
}

#if defined(CONFIG_SIM_MODE)
#include <windows.h>

static comm_ops_t*
_set_user_ops(comm_cfg_t *pCfg)
{
    extern comm_ops_t      g_comm_ops_host_sim;
    return &g_comm_ops_host_sim;
}

static void*
my_get_cur_time()
{
    return (void*)time(NULL);
}

static uint32_t
my_get_ms_duration(void *start)
{
    uint32_t    start_sec = (uint32_t)start;
    return (time(NULL) - start_sec) * 1000;
}

static void
my_usleep(uint32_t usec)
{
    Sleep(usec/1000);
    return;
}

static int
my_log(char *format, ...)
{
    static char     log_buf[256] = {0};
    va_list     arg;
    int         done = 0;

    va_start(arg, format);
    vsprintf(log_buf, format, arg);
    va_end(arg);

    puts(log_buf);
    return done;
}
#else

#define _set_user_ops     0
static void*
my_get_cur_time()
{
    static struct timeval   tm_start;
    gettimeofday(&tm_start, NULL);
    return (void*)&tm_start;
}

static uint32_t
my_get_ms_duration(void *start)
{
    struct timeval  *pTm_start = (struct timeval*)start;
    struct timeval  tm_cur;
    long            diff = 0l;

    gettimeofday(&tm_cur, NULL);

    diff = tm_cur.tv_sec * 1000 + tm_cur.tv_usec / 1000;
    diff -= (pTm_start->tv_sec * 1000 + pTm_start->tv_usec / 1000);
    return (uint32_t)diff;
}

static void
my_usleep(uint32_t usec)
{
    uleep(usec);
    return;
}

static int
my_log(char *format, ...)
{
    static char     log_buf[256] = {0};
    va_list     arg;
    int         done = 0;

    va_start(arg, format);
    vsprintf(log_buf, format, arg);
    va_end(arg);

    puts(log_buf);
    return done;
}
#endif

static int
_cmd_argv_parser(struct cmd_item *pCmd_item, char **argv, void *pTunnel_info)
{
    int             rval = 0;
    prog_argv_t     *pProg_argv = (prog_argv_t*)pTunnel_info;

    if( pCmd_item->uid == UID_PRIV_OPN_HELP )
    {
        return -1;
    }

    pProg_argv->uid = pCmd_item->uid;

    if( pCmd_item->flags == CMD_FLAG_COMMAND_TYPE )
        pProg_argv->isp_argv.cmd = pCmd_item->uid;

    for(int i = 0; i < pCmd_item->argument_cnt; i++)
    {
        switch( pCmd_item->uid )
        {
            default:
                pProg_argv->isp_argv.def.argv[i].pArgv = argv[i + 1];
                break;

            case UID_PRIV_OPN_COMMIF:
                pProg_argv->comm_if = (strcmp(argv[1], "spi") == 0)
                                    ? COMM_DEV_TYPE_SPI : COMM_DEV_TYPE_UART;
                break;

            case ISP_CMD_REBOOT:
            case ISP_CMD_WRITE_4BYTES:
            case ISP_CMD_READ_4BYTES:
            case ISP_CMD_READ_CHECKSUM:
                pProg_argv->uid = UID_PRIV_CMD_IGNORE;
                pProg_argv->isp_argv.cmd = pCmd_item->uid;
                pProg_argv->isp_argv.def.argv[i].integer_num = _str2int(argv[i + 1]);
                break;

            case UID_PRIV_CMD_ERASE:
                if( i == 0 )
                {
                    switch( _str2int(argv[i + 1]) )
                    {
                        case 0:     pProg_argv->isp_argv.cmd = ISP_CMD_ERASE_CHIP; break;
                        case 1:     pProg_argv->isp_argv.cmd = ISP_CMD_ERASE_SECTOR; break;
                        case 2:     pProg_argv->isp_argv.cmd = ISP_CMD_ERASE_PAGE; break;
                        case 3:     pProg_argv->isp_argv.cmd = ISP_CMD_ERASE_BLOCK; break;
                        default:    return -1; break;
                    }
                }
                else
                {
                    pProg_argv->isp_argv.def.argv[i - 1].integer_num = _str2int(argv[i + 1]);
                }
                break;

            case UID_PRIV_CMD_LOAD:
                pProg_argv->isp_argv.cmd = ISP_COMBO_CMD_LOAD;
                pProg_argv->isp_argv.def.argv[i].integer_num = (i == 3)
                                                             ? (uint32_t)argv[i + 1] : _str2int(argv[i + 1]);
                break;
        }
    }

    return rval;
}

static cmd_item_t       g_cmd_list[] =
{
    {.pCmd_name = "help", .argument_cnt = 0, .uid = UID_PRIV_OPN_HELP, .flags = CMD_FLAG_OPTION_TYPE,
        .pDescription = "  Command line help.\n"},
    {.pCmd_name = "--commif", .argument_cnt = 1, .uid = UID_PRIV_OPN_COMMIF, .flags = CMD_FLAG_OPTION_TYPE,
        .pDescription = "[interface] \n"
                        "  Communication interface uart or spi\n"
                        "  e.g. --commif uart or --commif spi\n"},
    {.pCmd_name = "ping", .argument_cnt = 0, .uid = ISP_CMD_PING, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "  Send peer-ping command.\n"},
    {.pCmd_name = "rd", .argument_cnt = 3, .uid = ISP_CMD_READ_4BYTES, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "[address] [bytes length] [layout]\n"
                        "  Read [bytes length] bytes data from [address]\n"
                        "  [layout]\n"
                        "       0: byte by byte\n"
                        "       1: 32 bits with little-endian \n\n"
                        "  e.g. rd 0x30044123 16 0\n"
                        "       read 16 bytes from 0x30044123\n"},
    {.pCmd_name = "wr", .argument_cnt = 2, .uid = ISP_CMD_WRITE_4BYTES, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "[address] [value (uint32)] \n"
                        "  Write [value (uint32)] to [address] \n"
                        "  e.g. wr 0x30044123 0xFFFF\n"
                        "       write value 0x0000FFFF to address 0x30044123\n"},
    {.pCmd_name = "reboot", .argument_cnt = 1, .uid = ISP_CMD_REBOOT, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "[remap type] \n"
                        "  Reboot remote with [remap type] \n"
                        "       0: type 0\n"
                        "       1: type 1\n"
                        "       2: type 2\n"},
    {.pCmd_name = "checksum", .argument_cnt = 2, .uid = ISP_CMD_READ_CHECKSUM, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "[address] [4*n bytes length]\n"
                        "  Checksum [4*n bytes length] bytes data from [address]\n"
                        "  e.g. rd 0x30044123 16 \n"
                        "       checksum 16 bytes from 0x30044123\n"},
    {.pCmd_name = "flashid", .argument_cnt = 0, .uid = ISP_CMD_GET_FLASH_ID, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "  Get Flash ID.\n"},
    {.pCmd_name = "erase", .argument_cnt = 3, .uid = UID_PRIV_CMD_ERASE, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "[erase mode] [address] [count]\n"
                        "  [erase mode]\n"
                        "       0: all chip\n"
                        "       1: sector\n"
                        "       2: page\n"
                        "       3: block\n"
                        "  erase [count] sectors/pages/blocks from [address] with [erase mode]\n"
                        "  e.g. erase 0 0 0 (erase chip)\n"
                        "       erase 1 0x00455200 3 (erase 3 sector from 0x00455200)\n"},
    {.pCmd_name = "remap", .argument_cnt = 0, .uid = ISP_CMD_GET_REMAP, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "  Get remap type.\n"},
    {.pCmd_name = "load", .argument_cnt = 4, .uid = UID_PRIV_CMD_LOAD, .flags = CMD_FLAG_COMMAND_TYPE,
        .pDescription = "[address] [send mode] [verify mode] [image path] \n"
                        "  load [image path] to [address] of remote\n"
                        "  [send mode]\n"
                        "       0: burst mode (fast)\n"
                        "       1: single mode\n"
                        "  [verify mode]\n"
                        "       0: remote response checksum\n"
                        "       1: host read and compare data\n"
                        "  e.g. load 0 0 ./test.bin"
                        },
    {.pCmd_name = 0,},
};

//=============================================================================
//                  Public Function Definition
//=============================================================================
static sys_port_t       g_sys_port =
{
    .pf_get_cur_time = my_get_cur_time,
    .pf_get_duration = my_get_ms_duration,
    .pf_usleep       = my_usleep,
    .pf_log          = my_log,
};

int main(int argc, char **argv)
{
    {   // setup program commands
        cmd_item_t  *pCmd_itm_cur = 0;

        cmd_util_init();

        pCmd_itm_cur = g_cmd_list;
        while( pCmd_itm_cur )
        {
            if( pCmd_itm_cur->pCmd_name == 0 )
                break;

            pCmd_itm_cur->pf_cmd_handler = _cmd_argv_parser;
            pCmd_itm_cur->pTunnel_info   = (void*)&g_prog_argv;
            cmd_util_register(pCmd_itm_cur);
            pCmd_itm_cur++;
        }
    }

    // parsing arguments
    if( cmd_util_parse_args(argc, argv) < 0 )
    {
        _usage();
    }


#if defined(CONFIG_SIM_MODE)
    {
        extern void* task_rom_code(void *argv);

        pthread_t   tsim;
        pthread_create(&tsim, 0, task_rom_code, &g_is_running_rom);
    }
#endif // #if defined(CONFIG_SIM_MODE)

    do {
        // initial ISP
        int             rval = 0;
        isp_setting_t   set_info = {0};

        sys_register_ops(&g_sys_port);

        set_info.dev_type        = g_prog_argv.comm_if;
        set_info.cb_set_user_ops = _set_user_ops;

        if( set_info.dev_type == COMM_DEV_TYPE_UART )
        {
            set_info.dev_attr.uart.baud_rate = 115200;
            set_info.dev_attr.uart.port      = 0;
        }
        else if( set_info.dev_type == COMM_DEV_TYPE_SPI )
        {
            set_info.dev_attr.spi.speed = 512000;
        }

        rval = isp_init(&set_info);
        if( rval )
        {
            err("initialize fail (err code: %d)\n", rval);
            break;
        }

        rval = isp_process(&g_prog_argv.isp_argv, 0, 0);
        if( rval )
        {
            err("process fail (err code: %d)\n", rval);
            break;
        }
    } while(0);

    isp_deinit();

#if defined(CONFIG_SIM_MODE)
    g_is_running_rom = 0;
    fprintf(stderr, "-------------------- end \n");
    while(1) Sleep(5000);
#endif // defined
    return 0;
}
