
#include <stdio.h>
#include <stdlib.h>
#include "log.h"
#include "comm_dev.h"

//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================
static comm_handle_t
_my_init(comm_cfg_t *pCfg)
{
    do {
    } while(0);

	return (comm_handle_t)0;
}

static int
_my_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    int     rval = 0;
    do {
    } while(0);
    return rval;
}

static int
_my_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    int     rval = 0;
    do {

    } while(0);
    return rval;
}

static int
_my_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
    return rval;
}

static int
_my_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
    } while(0);
    return rval;
}
static comm_ops_t   g_my_ops =
{
    .init          = _my_init,
    .send_bytes    = _my_send_bytes,
    .recv_bytes    = _my_recv_bytes,
    .get_state     = _my_get_state,
    .reset_buf     = _my_reset_buf,
};


static comm_ops_t*
_set_user_ops_t(comm_cfg_t *pCfg)
{
    return &g_my_ops;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
int main()
{
    comm_handle_t   hComm = 0;
    comm_cfg_t      cfg = {0};

    cfg.act_dev_type    = COMM_DEV_TYPE_UART;
    cfg.uart.baud_rate  = 115200;
    cfg.uart.port       = 1;
    hComm = comm_dev_init(&cfg, 0);
    if( !hComm )
    {
        err("%s", "communication device initial fail \n");
    }

    comm_dev_deinit(hComm);

    return 0;
}
