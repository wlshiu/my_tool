/**
 * Copyright (c) 2019 Wei-Lun Hsu. All Rights Reserved.
 */
/** @file comm_dev_sim.c
 *
 * @author Wei-Lun Hsu
 * @version 0.1
 * @date 2019/04/17
 * @license
 * @description
 */

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "comm_dev.h"
#include "queue.h"
#include "log.h"
//=============================================================================
//                  Constant Definition
//=============================================================================
#define ISP_CMD_ACK             0xF0
#define CONFIG_BUFFER_SIZE      2048
//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================
typedef struct comm_desc
{
    comm_handle_t       (*init)(comm_cfg_t *pCfg);
    int                 (*deinit)(comm_handle_t pHandle);

    /**
     *  @brief
     *
     *  @param [in] pHandle     communication handle
     *  @param [in] state       state type, enum comm_state
     *  @return
     *      0    : nothing
     *      other: the state is triggered
     */
    int     (*get_state)(comm_handle_t pHandle, comm_state_t state);

    /**
     *  @brief  send_bytes
     *
     *  @param [in] pHandle     communication handle
     *  @param [in] pData       data buffer pointer
     *  @param [in] data_len    length of data
     *  @return
     *      0: ok, other: fail
     */
    int     (*send_bytes)(comm_handle_t pHandle, uint8_t *pData, int data_len);

    /**
     *  @brief  recv_bytes
     *
     *  @param [in] pHandle     communication handle
     *  @param [in] pData       data buffer pointer
     *  @param [in] pData_len   length of data
     *  @return
     *      0: ok, other: fail
     */
    int     (*recv_bytes)(comm_handle_t pHandle, uint8_t *pData, int *pData_len);

    /**
     *  @brief  reset_buf
     *              This api will reset read/write index.
     *              It also support to assign new buffer adderss and new buffer length
     *
     *  @param [in] pBuf        new buffer address
     *  @param [in] buf_len     new buffer length
     *  @return
     *      0: ok, other: fail
     */
    int     (*reset_buf)(comm_handle_t pHandle, uint8_t *pBuf, uint32_t buf_len);
} comm_desc_t;
//=============================================================================
//                  Global Data Definition
//=============================================================================
static queue_handle_t       g_chnnl_q_0; // host tx -> rom rx
static queue_handle_t       g_chnnl_q_1; // rom tx -> host rx
//=============================================================================
//                  Private Function Definition
//=============================================================================
static int
_sim_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    int     rval = 0;
    do {
        queue_handle_t  *pHQ = (queue_handle_t*)pHandle;

        if( pHQ->pBuf == 0 )
        {
            if( !(pHQ->pBuf = malloc(CONFIG_BUFFER_SIZE)) )
            {
                rval = -1;
                break;
            }
            memset(pHQ->pBuf, 0x0, CONFIG_BUFFER_SIZE);
            pHQ->cur_len = 0;
        }

        memcpy(&pHQ->pBuf[pHQ->cur_len + 4], pData, data_len);
        pHQ->cur_len += data_len;
        *((int*)pHQ->pBuf) = pHQ->cur_len;

    } while(0);
    return rval;
}

static int
_sim_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    int     rval = 0;
    do {
        queue_handle_t  *pHQ = (queue_handle_t*)pHandle;
        uint8_t         *pBuf = 0;
        int             data_len = 0;
        int             rx_data_len = 0;

        data_len = *pData_len;
        *pData_len = 0;

        if( queue_is_empty(pHQ))
            break;

        if( (rval = queue_pop(pHQ, (int*)&pBuf)) < 0 )
            break;

        rx_data_len = *((int*)pBuf);

        if( data_len < rx_data_len )
        {
            err("rx data (len= %d) > buffer (len= %d)\n", rx_data_len, data_len);
        }
        else    data_len = rx_data_len;

        memcpy(pData, pBuf + sizeof(int), data_len);
        *pData_len = data_len;

        free(pBuf);
    } while(0);
    return rval;
}

static comm_handle_t
_host_sim_init(comm_cfg_t *pCfg)
{
    assert(pCfg);
    queue_init(&g_chnnl_q_0);

	return (comm_handle_t)&g_chnnl_q_0;
}

static int
_host_sim_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    return _sim_send_bytes(&g_chnnl_q_0, pData, data_len);
}

static int
_host_sim_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    return _sim_recv_bytes(&g_chnnl_q_1, pData, pData_len);
}

static int
_host_sim_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
//    queue_handle_t  *pHQ = (queue_handle_t*)pHandle;

    if( state == COMM_STATE_GET_RX_EVENT )
        rval = !queue_is_empty(&g_chnnl_q_1);

    return rval;
}

static int
_host_sim_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
        queue_handle_t  *pHQ = &g_chnnl_q_0;
        if( (rval = queue_push(pHQ, (int)pHQ->pBuf)) < 0 )
        {
            free(pHQ->pBuf);
            break;
        }

        // reset pBuf info
        pHQ->pBuf = 0;
    } while(0);
    return rval;
}

static comm_handle_t
_rom_sim_init(comm_cfg_t *pCfg)
{
    assert(pCfg);

    queue_init(&g_chnnl_q_1);

	return (comm_handle_t)&g_chnnl_q_1;
}

static int
_rom_sim_send_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             data_len)
{
    return _sim_send_bytes(&g_chnnl_q_1, pData, data_len);
}

static int
_rom_sim_recv_bytes(
    comm_handle_t   pHandle,
    uint8_t         *pData,
    int             *pData_len)
{
    return _sim_recv_bytes(&g_chnnl_q_0, pData, pData_len);
}

static int
_rom_sim_get_state(
    comm_handle_t   pHandle,
    comm_state_t    state)
{
    int             rval = 0;
//    queue_handle_t  *pHQ = (queue_handle_t*)pHandle;

    if( state == COMM_STATE_GET_RX_EVENT )
        rval = !queue_is_empty(&g_chnnl_q_0);

    return rval;
}

static int
_rom_sim_reset_buf(
    comm_handle_t   pHandle,
    uint8_t         *pBuf,
    uint32_t        buf_len)
{
    int             rval = 0;
    do {
        queue_handle_t  *pHQ = &g_chnnl_q_1;
        if( (rval = queue_push(pHQ, (int)pHQ->pBuf)) < 0 )
        {
            free(pHQ->pBuf);
            break;
        }

        // reset pBuf info
        pHQ->pBuf = 0;
    } while(0);
    return rval;
}
//=============================================================================
//                  Public Function Definition
//=============================================================================
comm_ops_t      g_comm_ops_host_sim =
{
    .init          = _host_sim_init,
    .send_bytes    = _host_sim_send_bytes,
    .recv_bytes    = _host_sim_recv_bytes,
    .get_state     = _host_sim_get_state,
    .reset_buf     = _host_sim_reset_buf,
};

comm_desc_t      g_comm_desc_rom_sim =
{
    .init          = _rom_sim_init,
    .send_bytes    = _rom_sim_send_bytes,
    .recv_bytes    = _rom_sim_recv_bytes,
    .get_state     = _rom_sim_get_state,
    .reset_buf     = _rom_sim_reset_buf,
};


