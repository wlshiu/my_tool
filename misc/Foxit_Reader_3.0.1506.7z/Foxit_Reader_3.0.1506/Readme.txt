What's New in Foxit Reader 3.0 Build 1506
======================================================================================================================
Vulnerabilities Fixed:

1. Fixed the issue of stack-based buffer overflow.
   Foxit PDF files include actions associated with different triggers. If an action (Open/Execute a file, Open a web link, etc.) is defined in the PDF files with an overly long filename argument and the trigger condition is satisfied, it will cause a stack-based buffer overflow.

2. Fixed the issue of security authorization bypass.
   If an action (Open/Execute a file, Open a web link, etc.) is defined in the PDF files and the trigger condition is satisfied, Foxit Reader will do the action defined by the creator of the PDF file without popping up a dialog box to confirm.

3. Fixed the issue of JBIG2 Symbol Dictionary Processing
   While decoding a JBIG2 symbol dictionary segment, an array of 32-bit elements is allocated having a size equal to the number of exported symbols, but left uninitialised if the number of new symbols is zero. The array is later accessed and values from uninitialised memory are used as pointers when reading memory and performing calls.

What's New in Foxit Reader 3.0 Build 1301
======================================================================================================================

Bug fixes:

Fixes a dead loop error in Foxit Reader Build 1222 when printing pages or a range of pages by entering 1, 3, 7-10 or whatever in the Pages text box within the Print dialog box. 


What's New in Foxit Reader 3.0 Build 1222
======================================================================================================================

The bugs fixed in this release include:

1. The annotations added by the typewriter tool will be rotated along with the page.
2. Pop up "Mozilla Firefox is not installed" when users failed to install Firefox plug-in.
3. May take a long time to open a file in Windows Vista Home version.
4. This updated version allows users to delete the advertisements.
5. The Auto-Rotate feature may be unavailable when printing with Snapshot tool.
6. Go back to the default settings of the printer properties when users reopen the PDF files.
7. This updated version will choose to print documents in actual size mode or fit to paper mode based on the default settings in the print dialog box with Command lines.
8. Page numbers are printed in a disorderly way when printing multiple copies in double-side mode.
9.The slow launch speed when running Foxit Reader for the first time after the system startup.


What's New in Foxit Reader 3.0 Build 1120
======================================================================================================================


The following is a list of exciting new and enhanced features in Foxit Reader 3.0.


New Features:

1. Enticing Multimedia Design
2. Attachment Panel
3. Thumbnail Panel
4. Layout Panel
5. Metric Unit Support
6. Auto-scrolling with Middle Mouse Button
7. Awe-Inspiring Foxit OnDemand Content Management
8. Firefox Support


Enhanced Features

1. Improved Select Text Tool
2. Enhanced Print Setup
3. Better Annotation Control
4. Advanced Toolbar Control
5. Better Permission Control
6. Improved Upgrade Mode
7. Improved Popup Note
8. Enhanced Shortcut Keys Input
9. Transferrable preferences Settings
10. Many Bug Fixes.




Known Issues
===========================================================================================================================================

1. Using <EMBED> to open PDF files within web pages using Foxit Reader is not supported.

2. Commenting tools including Highlight tool are not working very well when they are applied to vertical text.

3. Some European languages, such as Cyrillic, are not supported in the Pop-up note, typewriter tools and form fields.

4. Foxit Reader is not supported to fill PDF forms created by Adobe Designer.

5. The feature ��Retrieve poster from movie�� only applies to movie files of avi format.

6. PS printer compatibility issues �C prints blank pages or prints out with the wrong page numbers sometimes.




Download the Latest Version
========================================================================================================================
You can download the latest version of Foxit Reader from our website at www.foxitsoftware.com.




Contact Us
========================================================================================================================
If you have any questions using Foxit PDF Page Organizer, please contact us by email:

Sales and Information - sales@foxitsoftware.com
Marketing Serivce - marketing@foxitsoftware.com
Technical Support - support@foxitsoftware.com
Website Questions - webmaster@foxitsoftware.com



Foxit Software Company

Address: 39819 Paseo Padre Parkway, Fremont CA 94538, USA 

Sales Phone: 1-866-MYFOXIT or 1-866-693-6948 (8AM-5PM PST Monday - Friday) 
             510-438-9090 (8AM-5PM PST Monday - Friday)
             408-307-9358 (8AM-5PM PST Monday - Friday)

Support Phone: 1-866-MYFOXIT or 1-866-693-6948(24/7)
               979-446-0280 (6AM-5PM PST Monday - Friday)

Fax: 510-405-9288
Web: www.foxitsoftware.com