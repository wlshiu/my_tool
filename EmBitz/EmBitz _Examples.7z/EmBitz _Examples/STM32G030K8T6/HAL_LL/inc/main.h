
#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32g0xx_hal.h"
#include "stm32g0xx_ll_conf.h"





#ifdef __cplusplus
}
#endif

#endif /* MAIN_H_INCLUDED */
