/*
**
**                           Main.c
**
**
**********************************************************************/
/*
   Last committed:     $Revision: 00 $
   Last changed by:    $Author: $
   Last changed date:  $Date:  $
   ID:                 $Id:  $

**********************************************************************/

#include "main.h"


int main(void)
{

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    GPIO_InitTypeDef s;

    s.GPIO_Pin   = GPIO_Pin_1;
    s.GPIO_Mode  = GPIO_Mode_OUT;
    s.GPIO_OType = GPIO_OType_PP;
    s.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    s.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_Init(GPIOB, &s);

    while(1)
    {
        GPIOB->ODR ^= GPIO_ODR_1;
        for(volatile uint32_t i=0; i<1000000;i++);
    }
}

