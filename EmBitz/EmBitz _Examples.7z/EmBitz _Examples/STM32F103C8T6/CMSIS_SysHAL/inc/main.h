
#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx.h"





#ifdef __cplusplus
}
#endif

#endif /* MAIN_H_INCLUDED */
