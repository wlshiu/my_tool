/*
**
**                           Main.c
**
**
**********************************************************************/
/*
   Last committed:     $Revision: 00 $
   Last changed by:    $Author: $
   Last changed date:  $Date:  $
   ID:                 $Id:  $

**********************************************************************/

#include "main.h"

static uint32_t Delay_ms;


void DWT_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    DWT->CYCCNT = 0;
    Delay_ms = SystemCoreClock / 1000;
}

void DWT_Delay_ms(uint32_t ms) // � �������������
{
    uint32_t Count = DWT->CYCCNT;
    ms = ms * Delay_ms;
    while((DWT->CYCCNT - Count) < ms);
}

int main(void)
{
    SystemCoreClockUpdate();
    DWT_Init();

    RCC->APB2ENR |= RCC_APB2ENR_IOPCEN;
    GPIOC->CRH |= GPIO_CRH_MODE13;

    while(1)
    {
        GPIOC->ODR ^= GPIO_ODR_ODR13;
        DWT_Delay_ms(500);
    }
}

