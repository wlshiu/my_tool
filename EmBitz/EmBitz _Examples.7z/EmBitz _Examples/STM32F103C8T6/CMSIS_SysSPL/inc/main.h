
#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"





#ifdef __cplusplus
}
#endif

#endif /* MAIN_H_INCLUDED */
